// ignore_for_file: prefer_final_fields, unused_field, prefer_const_constructors, prefer_typing_uninitialized_variables, avoid_function_literals_in_foreach_calls

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uthmfoodie/model/cart_list_data_model.dart';
import 'package:uthmfoodie/model/cart_model.dart';
import 'package:uthmfoodie/model/user_order_model.dart';
import 'package:uthmfoodie/screens/order_screen_view.dart';
import 'package:uthmfoodie/strings/strings.dart';

class OrdersView extends StatefulWidget {
  const OrdersView({super.key});

  @override
  State<OrdersView> createState() => _OrdersViewState();
}

class _OrdersViewState extends State<OrdersView> {
  bool _isToday = false;
  String _menuItem = "";
  List<CartListData> _cloudCartList = [];

  @override
  void initState() {
    _fetchCartData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(10.0),
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Color.fromRGBO(255, 253, 235, 1.0)),
                onPressed: () => setState(() {
                  _isToday = !_isToday;
                }),
                child: Text(
                  _isToday ? Strings.btnClear : Strings.btnToday,
                  style: const TextStyle(color: Colors.black),
                ),
              ),
            ),
            Expanded(
              child: StreamBuilder(
                stream:
                    FirebaseFirestore.instance.collection('orders').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return ListView.builder(
                        itemCount: snapshot.data!.docs.length,
                        itemBuilder: (context, index) {
                          UserOrderData orders =
                              UserOrderData.fromDocumentSnapshot(
                                  snapshot.data!.docs[index]);
                          return Visibility(
                            visible: _setVisibility(orders),
                            child: InkWell(
                              onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (BuildContext ctx) =>
                                          OrderScreenView(orders: orders))),
                              child: Card(
                                child: Container(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text("Order Id: ${orders.orderId}"),
                                      const SizedBox(height: 20.0),
                                      Text(_getListOfOrderedItems(
                                          orders.orderId)),
                                      Text(
                                          "Order Date: ${DateFormat("dd/MM/yyyy hh:mm:ss aa").format(orders.orderDate)}"),
                                      Text(
                                          "Status: ${orders.isServed ? 'Completed' : 'Pending'}"),
                                      Text(
                                          "Order Type: ${orders.statusLevel == 0 ? Strings.lblDineIn : Strings.lblTakeAway}"),
                                      Text(
                                          "Order Time: ${orders.orderTime.isEmpty ? 'Now' : orders.orderTime}"),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        });
                  }
                  return Center();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  _setVisibility(UserOrderData orders) {
    if (_isToday) {
      return DateFormat("dd/MM/yyyy").format(orders.orderDate) ==
              DateFormat("dd/MM/yyyy").format(DateTime.now())
          ? true
          : false;
    } else {
      return true;
    }
  }

  _fetchCartData() async {
    var orderLists;
    var cartList;
    // Get OrderId First
    await FirebaseFirestore.instance.collection("orders").get().then(
          (value) => setState(() {
            orderLists =
                value.docs.map((e) => UserOrderData.fromMap(e.data())).toList();
          }),
        );

    for (UserOrderData uod in orderLists) {
      await FirebaseFirestore.instance
          .collection("orders")
          .doc(uod.orderId)
          .collection("listOfCart")
          .get()
          .then(
            (value) => setState(() {
              cartList =
                  value.docs.map((e) => CartData.fromMap(e.data())).toList();
              _cloudCartList
                  .add(CartListData(OrderId: uod.orderId, CartList: cartList));
            }),
          );
    }
  }

  String _getListOfOrderedItems(String orderId) {
    String temp = "";
    _cloudCartList.forEach((elementX) {
      if (elementX.OrderId == orderId) {
        int count = 1;
        elementX.CartList.forEach((elementY) {
          temp +=
              "- ${elementY.itemName} x ${elementY.itemQty}${count != elementX.CartList.length ? '\n' : ''}";
          count++;
        });
      }
    });
    return temp;
  }
}
