// ignore_for_file: empty_catches, unused_catch_clause, prefer_is_empty

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/model/promo_code_model.dart';
import 'package:uthmfoodie/model/user_order_model.dart';
import 'package:uthmfoodie/strings/strings.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final TextEditingController _promoCode = TextEditingController();
  final TextEditingController _promoCodePrice = TextEditingController();

  int _numbersOfPendingOrder = 0, _count = 0;

  @override
  void dispose() {
    _promoCode.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _resetInput();
    _getOrderCountForTheDay();
    _getPendingOrderCountForTheDay();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(10.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 50.0),
              Align(
                alignment: Alignment.centerRight,
                child: ElevatedButton.icon(
                  style:
                      ElevatedButton.styleFrom(backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0)),
                  onPressed: () => _refreshDetails(),
                  icon: const Icon(
                    Icons.refresh,
                    color: Color(0xff533c1c),
                  ),
                  label: Text(
                    Strings.btnRefresh,
                    style: const TextStyle(color: Color(0xff533c1c)),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        color: const Color(0xff533c1c),
                        elevation: 5.0,
                        child: Container(
                          height: 150.0,
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            children: [
                              Text(Strings.lblTotalOrders),
                              const SizedBox(height: 20.0),
                              Text(
                                _count.toString(),
                                style: const TextStyle(fontSize: 60.0),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        color: const Color(0xff533c1c),
                        elevation: 5.0,
                        child: Container(
                          height: 150.0,
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            children: [
                              Text(Strings.lblPendingOrders),
                              const SizedBox(height: 20.0),
                              Text(
                                _numbersOfPendingOrder.toString(),
                                style: const TextStyle(fontSize: 60.0),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 40.0),
              Card(
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      TextFormField(
                        decoration: InputDecoration(
                          border: const OutlineInputBorder(),
                          labelText: Strings.lblPromoCode,
                          labelStyle: const TextStyle(color: Color.fromRGBO(35, 29, 28, 1.0)),
                          floatingLabelStyle:
                              MaterialStateTextStyle.resolveWith(
                            (Set<MaterialState> states) {
                              final Color color =
                                  states.contains(MaterialState.error)
                                      ? Theme.of(context).colorScheme.error
                                      : const Color.fromRGBO(35, 29, 28, 1.0);
                              return TextStyle(
                                  color: color, letterSpacing: 1.3);
                            },
                          ),
                        ),
                        autovalidateMode: AutovalidateMode.always,
                        keyboardType: TextInputType.name,
                        controller: _promoCode,
                      ),
                      const SizedBox(height: 10.0),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              decoration: InputDecoration(
                                border: const OutlineInputBorder(),
                                labelText: Strings.lblPromoPrice,
                                labelStyle:
                                    const TextStyle(color: Color.fromRGBO(35, 29, 28, 1.0)),
                                floatingLabelStyle:
                                    MaterialStateTextStyle.resolveWith(
                                  (Set<MaterialState> states) {
                                    final Color color = states
                                            .contains(MaterialState.error)
                                        ? Theme.of(context).colorScheme.error
                                        : const Color.fromRGBO(35, 29, 28, 1.0);
                                    return TextStyle(
                                        color: color, letterSpacing: 1.3);
                                  },
                                ),
                              ),
                              autovalidateMode: AutovalidateMode.always,
                              keyboardType: TextInputType.number,
                              controller: _promoCodePrice,
                            ),
                          ),
                          const SizedBox(width: 10.0),
                          SizedBox(
                            height: 60.0,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                                shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(10.0),
                                  ),
                                ),
                              ),
                              onPressed: () => _addPromoCodeIntoCloud(),
                              child: Text(
                                Strings.btnAddCode,
                                style:
                                    TextStyle(color: CustomAppColor.secondary),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: 200.0,
                  padding: const EdgeInsets.all(20.0),
                  child: StreamBuilder(
                    stream: FirebaseFirestore.instance
                        .collection("promos")
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        if (snapshot.data!.docs.isNotEmpty) {
                          return ListView.builder(
                              itemCount: snapshot.data!.docs.length,
                              itemBuilder: (context, index) {
                                PromoCodeData code =
                                    PromoCodeData.fromDocumentSnapshot(
                                        snapshot.data!.docs[index]);
                                return Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 5.0),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SingleChildScrollView(
                                          child: Row(
                                            children: [
                                              InkWell(
                                                onTap: () => _switchMode(code),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        const BorderRadius.all(
                                                      Radius.circular(10.0),
                                                    ),
                                                    color: code.isActive
                                                        ? Colors.green
                                                        : Colors.red,
                                                  ),
                                                  padding:
                                                      const EdgeInsets.all(5.0),
                                                  child: Text(code.isActive
                                                      ? Strings.lblActive
                                                      : Strings.lblInActive),
                                                ),
                                              ),
                                              const SizedBox(width: 10.0),
                                              Text(
                                                  "${code.promoCode} | RM${code.price.toStringAsFixed(2)}"),
                                            ],
                                          ),
                                        ),
                                      ),
                                      ElevatedButton(
                                        onPressed: () =>
                                            _removePromoCodeItem(code),
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0)),
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.delete,
                                              color: CustomAppColor.secondary,
                                            ),
                                            const SizedBox(width: 5.0),
                                            Text(
                                              Strings.btnRemoveItem,
                                              style: TextStyle(
                                                  color:
                                                      CustomAppColor.secondary),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              });
                        } else {
                          return Center(
                            child: Text(
                              Strings.lblNonPromoCodeAvailable,
                              style: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                            ),
                          );
                        }
                      }
                      return Center(
                        child: Text(
                          Strings.lblNonPromoCodeAvailable,
                          style: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                        ),
                      );
                    },
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  _addPromoCodeIntoCloud() async {
    try {
      var promoCollection = FirebaseFirestore.instance.collection("promos");
      PromoCodeData code = PromoCodeData(
          promoCode: _promoCode.text,
          price: double.parse(_promoCodePrice.text),
          isActive: true);

      if (code.promoCode.isNotEmpty && code.price > 0) {
        await promoCollection
            .doc(code.promoCode)
            .set(code.toMap())
            .then((value) => _resetInput());
      }
    } on FirebaseException catch (e) {}
  }

  _removePromoCodeItem(PromoCodeData code) async {
    try {
      var promoCollection = FirebaseFirestore.instance.collection("promos");

      await promoCollection.doc(code.promoCode).delete();
    } on FirebaseException catch (e) {}
  }

  _resetInput() {
    setState(() {
      _promoCodePrice.text = "";
      _promoCode.text = "";
    });
  }

  _switchMode(PromoCodeData code) async {
    try {
      var promoCollection = FirebaseFirestore.instance.collection("promos");

      await promoCollection
          .doc(code.promoCode)
          .update({"isActive": !code.isActive});
    } on FirebaseException catch (e) {}
  }

  _getOrderCountForTheDay() async {
    await FirebaseFirestore.instance
        .collection("orders")
        .get()
        .then(
          (value) => _computeOrderOfTheDay(value)
        )
        .onError(
          (error, stackTrace) => setState(() {
            _count = 0;
          }),
        );
  }

  _getPendingOrderCountForTheDay() async {
    await FirebaseFirestore.instance
        .collection("orders")
        .get()
        .then((value) => _getOrderPendingDetails(value))
        .onError(
          (error, stackTrace) => setState(() {
            _numbersOfPendingOrder = 0;
          }),
        );
  }

  _refreshDetails() {
    _getOrderCountForTheDay();
    _getPendingOrderCountForTheDay();
  }

  _getOrderPendingDetails(QuerySnapshot<Map<String, dynamic>> value) {
    List<UserOrderData> orders;
    orders = value.docs.map((e) => UserOrderData.fromMap(e.data())).toList();
    List<UserOrderData> tempHolder = orders
        .where((element) =>
            DateFormat("dd/MM/yyyy").format(element.orderDate) ==
            DateFormat("dd/MM/yyyy").format(DateTime.now()))
        .where((element) => element.isServed == false)
        .toList();

    setState(() {
      if (tempHolder.length > 0){
        _numbersOfPendingOrder = tempHolder.length;

      } else {
        _numbersOfPendingOrder = 0;
      }
    });
  }

  _computeOrderOfTheDay(QuerySnapshot<Map<String, dynamic>> value) {
    List<UserOrderData> orders;
    orders = value.docs.map((e) => UserOrderData.fromMap(e.data())).toList();
    List<UserOrderData> tempHolder = orders
        .where((element) =>
    DateFormat("dd/MM/yyyy").format(element.orderDate) ==
        DateFormat("dd/MM/yyyy").format(DateTime.now()))
        .toList();

    setState(() {
      if (tempHolder.isNotEmpty){
        _count = tempHolder.length;

      } else {
        _count = 0;
      }
    });

  }
}
