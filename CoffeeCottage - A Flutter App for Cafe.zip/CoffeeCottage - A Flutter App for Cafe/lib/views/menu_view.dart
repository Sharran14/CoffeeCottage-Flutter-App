// ignore_for_file: prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/model/food_menu.dart';
import 'package:uthmfoodie/screens/add_item_screen.dart';
import 'package:uthmfoodie/screens/view_item_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';

class MenuView extends StatefulWidget {
  const MenuView({super.key});

  @override
  State<MenuView> createState() => _MenuViewState();
}

class _MenuViewState extends State<MenuView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(10.0),
        child: StreamBuilder(
          stream: FirebaseFirestore.instance.collection('seller').snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return ListView.builder(
                  itemCount: snapshot.data!.docs.length,
                  itemBuilder: (context, index) {
                    FoodMenu foodMenu = FoodMenu.fromDocumentSnapshot(
                        snapshot.data!.docs[index]);
                    return InkWell(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext context) =>
                              ViewItemScreen(productName: foodMenu.itemName),
                        ),
                      ),
                      child: Card(
                        elevation: 5,
                        child: Container(
                          padding: const EdgeInsets.all(10.0),
                          height: 100.0,
                          child: Row(
                            children: [
                              Container(
                                width: 80.0,
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(10.0),
                                  ),
                                  image: DecorationImage(
                                    image: NetworkImage(foodMenu.itemImage),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10.0),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 10.0),
                                    Text(
                                      foodMenu.itemName,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8.0),
                                      child: Text(
                                        foodMenu.itemDescription,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Text(
                                      "Nutrition: ${foodMenu.itemNutrition}",
                                      overflow: TextOverflow.ellipsis,
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 50,
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(top: 10.0),
                                      child: InkWell(
                                        child: const Icon(
                                          Icons.edit,
                                          color: Colors.green,
                                        ),
                                        onTap: () => Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                AddItemScreen(
                                                    productName:
                                                        foodMenu.itemName),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10.0),
                                      child: InkWell(
                                        child: const Icon(
                                          Icons.delete,
                                          color: Colors.red,
                                        ),
                                        onTap: () =>
                                            _removeItem(foodMenu.itemName),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  });
            } else {
              return SizedBox();
            }
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
          backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
          onPressed: () => _addItem(),
          icon: Icon(
            Icons.add,
            color: CustomAppColor.secondary,
          ),
          label: Text(
            Strings.btnAddMenu,
            style: TextStyle(color: CustomAppColor.secondary),
          )),
    );
  }

  _addItem() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => const AddItemScreen(
          productName: '',
        ),
      ),
    );
  }

  _removeItem(String itemName) {
    var sellerCollection = FirebaseFirestore.instance.collection("seller");
    sellerCollection.doc(itemName).delete();
  }
}
