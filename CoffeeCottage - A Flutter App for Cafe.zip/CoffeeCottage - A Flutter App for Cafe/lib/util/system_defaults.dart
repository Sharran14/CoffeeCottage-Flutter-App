import 'package:flutter/material.dart';

class SystemDefaults {
  static showSnackBar(
      {required BuildContext context,
      required String msg,
      required int duration}) {
    var snackBar = SnackBar(
      content: Text(msg),
      duration: Duration(seconds: duration),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }
}
