// ignore_for_file: non_constant_identifier_names, unused_field, unused_local_variable, prefer_interpolation_to_compose_strings, avoid_print, avoid_function_literals_in_foreach_calls

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:forex_conversion/forex_conversion.dart';
import 'package:intl/intl.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/model/cart_model.dart';
import 'package:uthmfoodie/model/user_order_model.dart';
import 'package:uthmfoodie/util/peyment_service.dart';
import 'package:webview_flutter/webview_flutter.dart';

class Payment extends StatefulWidget {
  final Function onFinish;

  const Payment({super.key, required this.onFinish});

  @override
  State<Payment> createState() => _PaymentState();
}

class _PaymentState extends State<Payment> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String? checkoutUrl;
  String? executeUrl;
  String? accessToken;
  PaypalServices services = PaypalServices();
  UserOrderData orderData = UserOrderData(
      orderId: "",
      email: "",
      promoCode: "",
      promoDiscountPrice: 0,
      totalPrice: 0,
      priceAfterDiscount: 0,
      orderDate: DateTime.now(),
      isServed: true,
      isPaid: false,
      isPrep: false,
      isInKitchen: false,
      isComplete: false,
      servedTime: DateTime.now(),
      statusLevel: 0,
      orderTime: '');
  List<CartData> _listOfCart = [];
  double usd = 0;

  // You may alter the default value to whatever you like.
  Map<dynamic, dynamic> defaultCurrency = {
    "symbol": "USD ",
    "decimalDigits": 2,
    "symbolBeforeTheNumber": true,
    "currency": "USD"
  };

  bool isEnableShipping = false;
  bool isEnableAddress = false;

  String returnURL = 'return.example.com';
  String cancelURL = 'cancel.example.com';

  @override
  void initState() {
    super.initState();

    _getOrderDetails();
    Future.delayed(Duration.zero, () async {
      try {
        accessToken = await services.getAccessToken();

        final transactions = getOrderParams();
        final res =
            await services.createPaypalPayment(transactions, accessToken);
        if (res != null) {
          setState(() {
            checkoutUrl = res["approvalUrl"];
            executeUrl = res["executeUrl"];
          });
        }
      } catch (ex) {
        final snackBar = SnackBar(
          content: Text(ex.toString()),
          duration: const Duration(seconds: 10),
          action: SnackBarAction(
            label: 'Close',
            onPressed: () {
              // Some code for undoing the alteration.
            },
          ),
        );
        // _scaffoldKey.currentState!.showSnackBar(snackBar);
      }
    });
  }

  // item name, price and quantity here
  String itemName = 'One plus 10';
  String itemPrice = '100';
  int quantity = 1;

  Map<String, dynamic> getOrderParams() {
    _convert();
    List items = [
      {
        "name": orderData.orderId,
        "quantity": quantity,
        "price": usd,
        "currency": defaultCurrency["currency"]
      }
    ];

    // Checkout Invoice Specifics
    String totalAmount = '100';
    String subTotalAmount = '100';
    String shippingCost = '0';
    int shippingDiscountCost = 0;
    String userFirstName = 'john';
    String userLastName = 'smith';
    String addressCity = 'USA';
    String addressStreet = "i-10";
    String addressZipCode = '44000';
    String addressCountry = 'Pakistan';
    String addressState = 'Islamabad';
    String addressPhoneNumber = '+1 223 6161 789';

    Map<String, dynamic> temp = {
      "intent": "sale",
      "payer": {"payment_method": "paypal"},
      "transactions": [
        {
          "amount": {
            "total": totalAmount,
            "currency": defaultCurrency["currency"],
            "details": {
              "subtotal": subTotalAmount,
              "shipping": shippingCost,
              "shipping_discount": ((-1.0) * shippingDiscountCost).toString()
            }
          },
          "description": "The payment transaction description.",
          "payment_options": {
            "allowed_payment_method": "INSTANT_FUNDING_SOURCE"
          },
          "item_list": {
            "items": items,
            if (isEnableShipping && isEnableAddress)
              "shipping_address": {
                "recipient_name": userFirstName + " " + userLastName,
                "line1": addressStreet,
                "line2": "",
                "city": addressCity,
                "country_code": addressCountry,
                "postal_code": addressZipCode,
                "phone": addressPhoneNumber,
                "state": addressState
              },
          }
        }
      ],
      "note_to_payer": "Contact us for any questions on your order.",
      "redirect_urls": {"return_url": returnURL, "cancel_url": cancelURL}
    };
    return temp;
  }

  @override
  Widget build(BuildContext context) {
    print(checkoutUrl);

    if (checkoutUrl != null) {
      return Scaffold(
        appBar: AppBar(
          // backgroundColor: Theme.of(context).backgroundColor,
          leading: GestureDetector(
            child: const Icon(Icons.arrow_back_ios),
            onTap: () => Navigator.pop(context),
          ),
        ),
        body: WebView(
          initialUrl: checkoutUrl,
          javascriptMode: JavascriptMode.unrestricted,
          navigationDelegate: (NavigationRequest request) {
            if (request.url.contains(returnURL)) {
              final uri = Uri.parse(request.url);
              final payerID = uri.queryParameters['PayerID'];
              if (payerID != null) {
                services
                    .executePayment(executeUrl, payerID, accessToken)
                    .then((id) {
                  widget.onFinish(id);
                  Navigator.of(context).pop();
                });
              } else {
                Navigator.of(context).pop();
              }
              Navigator.of(context).pop();
            }
            if (request.url.contains(cancelURL)) {
              Navigator.of(context).pop();
            }
            return NavigationDecision.navigate;
          },
        ),
      );
    } else {
      return Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.of(context).pop();
              }),
          backgroundColor: Colors.black12,
          elevation: 0.0,
        ),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
  }

  _getOrderDetails() async {
    await FirebaseFirestore.instance
        .collection("orders")
        .where("email", isEqualTo: AuthController.getUserEmail())
        .get()
        .then(
          (value) => value.docs.forEach(
            (element) {
              DateFormat dateFormat = DateFormat("dd/MM/yyyy");
              if (dateFormat.format(element["orderDate"].toDate()) ==
                  dateFormat.format(DateTime.now())) {
                if (!element["isServed"]) {
                  setState(() {
                    orderData = UserOrderData.fromMap(element.data());
                  });
                }
              }
            },
          ),
        )
        .then((value) async => await _fetchFoodMenuDetails());
  }

  _fetchFoodMenuDetails() async {
    await FirebaseFirestore.instance
        .collection("orders/${orderData.orderId}/listOfCart")
        .get()
        .then(
          (value) => _loadCartItemsIntoList(value),
        );
  }

  _loadCartItemsIntoList(QuerySnapshot<Map<String, dynamic>> value) {
    List<CartData> tempList = [];
    value.docs.forEach((element) {
      CartData cart = CartData.fromMap(element.data());
      tempList.add(cart);
    });

    setState(() {
      _listOfCart = tempList;
    });
  }

  void _convert() async {
    final fx = Forex();

    final double myPriceInUSD = await fx.getCurrencyConverted(
        sourceCurrency: "MYR",
        destinationCurrency: "USD",
        sourceAmount: orderData.priceAfterDiscount);
    setState(() {
      usd = myPriceInUSD;
    });
  }
  
  WebView({String? initialUrl, required javascriptMode, required NavigationDecision Function(NavigationRequest request) navigationDelegate}) {}
}
