// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/screens/splashscreen.dart';
import 'package:uthmfoodie/strings/strings.dart';

class FoodieApp extends StatelessWidget {
  const FoodieApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Set orientiation to be vertically static
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    return MaterialApp(
      title: Strings.appName,
      themeMode: ThemeMode.dark,
      // darkTheme: ThemeData.dark(useMaterial3: true),
      theme: ThemeData(
        colorScheme: const ColorScheme.dark().copyWith(
          primary: const Color.fromRGBO(255, 253, 235, 1.0),
          secondary: CustomAppColor.secondary,
          onError: const Color.fromARGB(255, 122, 121, 121),
        ),
      ),
      debugShowCheckedModeBanner: false,
      home: const SplashScreen(),
    );
  }
}
