import 'dart:ui';

class CustomAppColor {
  static Color primary = const Color(0xffa67c00);
  static Color secondary = const Color(0xff533c1c);
}
