import 'package:cloud_firestore/cloud_firestore.dart';

class BasicUserData {
  final String email;
  final DateTime dateJoined;
  final bool isCompleted;

  BasicUserData(
      {required this.email,
      required this.dateJoined,
      required this.isCompleted});

  Map<String, dynamic> toMap() {
    return {
      "email": email,
      "dateJoined": dateJoined,
      "isCompleted": isCompleted,
    };
  }

  BasicUserData.fromMap(Map<String, dynamic> data)
      : email = data["email"],
        dateJoined = data["dateJoined"].toDate(),
        isCompleted = data["isCompleted"];

  BasicUserData.fromDocumentSnapshot(DocumentSnapshot<Map<String, dynamic>> doc)
      : email = doc.data()!["email"],
        dateJoined = doc.data()!["dateJoined"].toDate(),
        isCompleted = doc.data()!["isCompleted"];
}
