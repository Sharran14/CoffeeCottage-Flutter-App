import 'package:cloud_firestore/cloud_firestore.dart';

class PromoCodeData {
  final String promoCode;
  final double price;
  final bool isActive;

  PromoCodeData(
      {required this.promoCode, required this.price, required this.isActive});

  Map<String, dynamic> toMap() {
    return {
      "promoCode": promoCode,
      "price": price,
      "isActive": isActive,
    };
  }

  PromoCodeData.fromMap(Map<String, dynamic> data)
      : promoCode = data["promoCode"],
        price = data["price"],
        isActive = data["isActive"];

  PromoCodeData.fromDocumentSnapshot(DocumentSnapshot<Map<String, dynamic>> doc)
      : promoCode = doc.data()!["promoCode"],
        price = doc.data()!["price"],
        isActive = doc.data()!["isActive"];
}
