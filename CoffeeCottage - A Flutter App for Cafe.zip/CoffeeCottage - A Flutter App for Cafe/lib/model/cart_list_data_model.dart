// ignore_for_file: non_constant_identifier_names

import 'package:uthmfoodie/model/cart_model.dart';

class CartListData {
  String OrderId;
  List<CartData> CartList;

  CartListData({required this.OrderId, required this.CartList});
}
