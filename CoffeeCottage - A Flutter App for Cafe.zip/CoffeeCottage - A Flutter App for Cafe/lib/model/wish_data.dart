import 'package:cloud_firestore/cloud_firestore.dart';

class WishData {
  String uid, email;

  WishData({required this.uid, required this.email});

  Map<String, dynamic> toMap() {
    return {"uid": uid, "email": email};
  }

  WishData.fromMap(Map<String, dynamic> data)
      : uid = data["uid"],
        email = data["email"];

  WishData.fromDocumentSnapshot(DocumentSnapshot<Map<String, dynamic>> doc)
      : uid = doc.data()!["uid"],
        email = doc.data()!["email"];
}
