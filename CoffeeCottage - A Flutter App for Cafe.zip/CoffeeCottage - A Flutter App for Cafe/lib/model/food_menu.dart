import 'package:cloud_firestore/cloud_firestore.dart';

class FoodMenu {
  final String itemName, itemDescription, itemNutrition, itemImage, itemType;
  final double itemPrice, itemDiscount;
  final int itemAvailabilityPerOrder;

  FoodMenu(
      {required this.itemName,
      required this.itemDescription,
      required this.itemNutrition,
      required this.itemImage,
      required this.itemPrice,
      required this.itemDiscount,
      required this.itemAvailabilityPerOrder,
      required this.itemType});

  Map<String, dynamic> toMap() {
    return {
      "itemName": itemName,
      "itemDescription": itemDescription,
      "itemNutrition": itemNutrition,
      "itemImage": itemImage,
      "itemPrice": itemPrice,
      "itemDiscount": itemDiscount,
      "itemAvailabilityPerOrder": itemAvailabilityPerOrder,
      "itemType": itemType,
    };
  }

  FoodMenu.fromMap(Map<String, dynamic> data)
      : itemName = data["itemName"],
        itemDescription = data["itemDescription"],
        itemNutrition = data["itemNutrition"],
        itemImage = data["itemImage"],
        itemPrice = data["itemPrice"],
        itemDiscount = data["itemDiscount"],
        itemAvailabilityPerOrder = data["itemAvailabilityPerOrder"],
        itemType = data["itemType"];

  FoodMenu.fromDocumentSnapshot(DocumentSnapshot<Map<String, dynamic>> doc)
      : itemName = doc.data()!["itemName"],
        itemDescription = doc.data()!["itemDescription"],
        itemNutrition = doc.data()!["itemNutrition"],
        itemImage = doc.data()!["itemImage"],
        itemPrice = doc.data()!["itemPrice"],
        itemDiscount = doc.data()!["itemDiscount"],
        itemAvailabilityPerOrder = doc.data()!["itemAvailabilityPerOrder"],
        itemType = doc.data()!["itemType"];
}
