import 'package:cloud_firestore/cloud_firestore.dart';

class CartData {
  String transId, email, itemName;
  int itemQty;
  double itemPrice, itemDiscount, totalItemPrice;

  CartData(
      {required this.transId,
      required this.email,
      required this.itemName,
      required this.itemQty,
      required this.itemPrice,
      required this.itemDiscount,
      required this.totalItemPrice});

  Map<String, dynamic> toMap() {
    return {
      "transId": transId,
      "email": email,
      "itemName": itemName,
      "itemQty": itemQty,
      "itemPrice": itemPrice,
      "itemDiscount": itemDiscount,
      "totalItemPrice": totalItemPrice
    };
  }

  CartData.fromMap(Map<String, dynamic> data)
      : transId = data["transId"],
        email = data["email"],
        itemName = data["itemName"],
        itemQty = data["itemQty"],
        itemPrice = data["itemPrice"],
        itemDiscount = data["itemDiscount"],
        totalItemPrice = data["totalItemPrice"];

  CartData.fromDocumentSnapshot(DocumentSnapshot<Map<String, dynamic>> doc)
      : transId = doc.data()!["transId"],
        email = doc.data()!["email"],
        itemName = doc.data()!["itemName"],
        itemQty = doc.data()!["itemQty"],
        itemPrice = doc.data()!["itemPrice"],
        itemDiscount = doc.data()!["itemDiscount"],
        totalItemPrice = doc.data()!["totalItemPrice"];
}
