import 'package:cloud_firestore/cloud_firestore.dart';

class UserOrderData {
  String orderId, email, promoCode, orderTime;
  double promoDiscountPrice, totalPrice, priceAfterDiscount;
  bool isPrep, isInKitchen, isComplete;
  DateTime orderDate, servedTime;
  bool isServed, isPaid;
  int statusLevel;

  UserOrderData(
      {required this.orderId,
      required this.email,
      required this.promoCode,
      required this.promoDiscountPrice,
      required this.totalPrice,
      required this.priceAfterDiscount,
      required this.orderDate,
      required this.isServed,
      required this.isPaid,
      required this.isPrep,
      required this.isInKitchen,
      required this.isComplete,
      required this.servedTime,
      required this.statusLevel,
      required this.orderTime});

  Map<String, dynamic> toMap() {
    return {
      "orderId": orderId,
      "email": email,
      "promoCode": promoCode,
      "promoDiscountPrice": promoDiscountPrice,
      "totalPrice": totalPrice,
      "priceAfterDiscount": priceAfterDiscount,
      "orderDate": orderDate,
      "isServed": isServed,
      "isPaid": isPaid,
      "isPrep": isPrep,
      "isInKitchen": isInKitchen,
      "isComplete": isComplete,
      "servedTime": servedTime,
      "statusLevel": statusLevel,
      "orderTime": orderTime,
    };
  }

  UserOrderData.fromMap(Map<String, dynamic> data)
      : orderId = data["orderId"],
        email = data["email"],
        promoCode = data["promoCode"],
        promoDiscountPrice = data["promoDiscountPrice"],
        totalPrice = data["totalPrice"],
        priceAfterDiscount = data["priceAfterDiscount"],
        orderDate = data["orderDate"].toDate(),
        isServed = data["isServed"],
        isPaid = data["isPaid"],
        isPrep = data["isPrep"],
        isInKitchen = data["isInKitchen"],
        isComplete = data["isComplete"],
        statusLevel = data["statusLevel"],
        servedTime = data["servedTime"].toDate(),
        orderTime = data["orderTime"];

  UserOrderData.fromDocumentSnapshot(DocumentSnapshot<Map<String, dynamic>> doc)
      : orderId = doc.data()!["orderId"],
        email = doc.data()!["email"],
        promoCode = doc.data()!["promoCode"],
        promoDiscountPrice = doc.data()!["promoDiscountPrice"],
        totalPrice = doc.data()!["totalPrice"],
        priceAfterDiscount = doc.data()!["priceAfterDiscount"],
        orderDate = doc.data()!["orderDate"].toDate(),
        isServed = doc.data()!["isServed"],
        isPaid = doc.data()!["isPaid"],
        isPrep = doc.data()!["isPrep"],
        isInKitchen = doc.data()!["isInKitchen"],
        isComplete = doc.data()!["isComplete"],
        statusLevel = doc.data()!["statusLevel"],
        servedTime = doc.data()!["servedTime"].toDate(),
        orderTime = doc.data()!["orderTime"];

  UserOrderData.fromJson(Map<String, dynamic> json)
      : orderId = json["orderId"],
        email = json["email"],
        promoCode = json["promoCode"],
        promoDiscountPrice = json["promoDiscountPrice"],
        totalPrice = json["totalPrice"],
        priceAfterDiscount = json["priceAfterDiscount"],
        orderDate = json["orderDate"].toDate(),
        isServed = json["isServed"],
        isPaid = json["isPaid"],
        isPrep = json["isPrep"],
        isInKitchen = json["isInKitchen"],
        isComplete = json["isComplete"],
        statusLevel = json["statusLevel"],
        servedTime = json["servedTime"].toDate(),
        orderTime = json["orderTime"];
}
