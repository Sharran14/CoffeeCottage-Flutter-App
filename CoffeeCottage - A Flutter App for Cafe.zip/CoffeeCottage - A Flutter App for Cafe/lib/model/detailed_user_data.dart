// ignore_for_file: use_super_parameters, annotate_overrides

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uthmfoodie/model/basic_user_data.dart';

class DetailedUserData extends BasicUserData {
  final String fullname, nickname, phoneNumber;

  DetailedUserData(
      {required this.fullname,
      required this.nickname,
      required this.phoneNumber,
      required super.email,
      required super.dateJoined,
      required super.isCompleted});

  Map<String, dynamic> toMap() {
    return {
      "fullname": fullname,
      "nickname": nickname,
      "phoneNumber": phoneNumber,
      "email": email,
      "dateJoined": dateJoined,
      "isCompleted": isCompleted,
    };
  }

  DetailedUserData.fromMap(Map<String, dynamic> data)
      : fullname = data["fullname"],
        nickname = data["nickname"],
        phoneNumber = data["phoneNumber"],
        super.fromMap(data);

  DetailedUserData.fromDocumentSnapshot(
      DocumentSnapshot<Map<String, dynamic>> doc)
      : fullname = doc.data()!["fullname"],
        nickname = doc.data()!["nickname"],
        phoneNumber = doc.data()!["phoneNumber"],
        super.fromDocumentSnapshot(doc);
}
