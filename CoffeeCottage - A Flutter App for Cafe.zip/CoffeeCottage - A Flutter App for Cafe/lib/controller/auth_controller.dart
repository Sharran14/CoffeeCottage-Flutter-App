import 'package:firebase_auth/firebase_auth.dart';

class AuthController {
  static FirebaseAuth ins = FirebaseAuth.instance;

  static bool isActiveUser() => (ins.currentUser != null) ? true : false;

  static String getUserEmail() => ins.currentUser!.email.toString();

  static void resetPassword() =>
      ins.sendPasswordResetEmail(email: getUserEmail());

  static signOut() async => await ins.signOut();
}
