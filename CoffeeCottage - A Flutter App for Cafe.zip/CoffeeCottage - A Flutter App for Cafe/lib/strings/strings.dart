// ignore_for_file: non_constant_identifier_names

class Strings {
  static String appName = "COFFEE COTTAGE ft NIBONG TEBAL";
  static String appNameShort = "COFFEE COTTAGE";
  static String lblAppName = "COFFEE COTTAGE ft \nNIBONG \nTEBAL";

  static String lblExistingUserTitle = "Login me! I'm a existing user";
  static String lblNewUserTitle = "Register me! I'm a new user";
  static String lblForgotTitle =
      "I forgot my password! Please help me to reset it.";

  static String lblEmail = "Email";
  static String lblPassword = "Password";
  static String lblConfPassword = "Confirm Password";
  static String lblWelcome = "Welcome";
  static String lblFullName = "Full Name";
  static String lblNickName = "Nickname";
  static String lblDOB = "Date of Birth";
  static String lblIsAdmin = "I'm an admin";
  static String lblIsSeller = "I'm a seller";
  static String lblAdminPassword = "Admin Password";
  static String lblBusinessName = "Business Name";
  static String lblBusinessDesc = "Business Description";
  static String lblMobileNumber = "Mobile Number";
  static String lblAllow = "Approve";
  static String lblDeny = "Decline";
  static String lblDateRegistered = "Date Registered";
  static String lblBusinessStatus = "Business Approval Status";
  static String lblPhotoLibrary = "Gallery";
  static String lblPhotoCamera = "Camera";
  static String lblItemName = "Item Name";
  static String lblItemDesc = "Description";
  static String lblItemNutrition = "Nutrition";
  static String lblStaffLogin = "Staff Login";
  static String lblUserLogin = "User Login";
  static String lblCreateAcc = "Create Account";
  static String lblCreateAccDesc = "Create New User Account";
  static String lblForgotPassTitle = "Forgot Password";
  static String lblForgotPassTitleDesc = "Change Password";
  static String lblUpdateAcc = "Update Account";
  static String lblUpdateAccDesc = "Update User Account";
  static String lblNumberOfOrders = "Number of Orders";
  static String lblAddToCart = "Add to Cart";
  static String lblSearch = "Search Item";
  static String lblPrice = "Price";
  static String lblDiscount = "Discount";
  static String lblAvailability = "Availability";
  static String lblPromoCode = "Promo Code";
  static String lblTotalPrice = "Total Price";
  static String lblDiscountPromo = "Discount for $lblPromoCode";
  static String lblPromoPrice = "Discount Price for $lblPromoCode";
  static String lblNonPromoCodeAvailable = "There's no code(s) added now";
  static String lblActive = "Active";
  static String lblInActive = "InActive";
  static String lblItemType = "Item type";
  static String lblLogout = "Logout";
  static String lblCurrentOrderStatus = "Current Order Status";
  static String lblOrderHistory = "Order History";
  static String lblNoActiveOrders = "No Active Orders";
  static String lblNoOrders = "There's no order history for now";
  static String lblItem = "Item(s)";
  static String lblRefresh = "Refresh";
  static String lblCartTitle = "$appName | Cart";
  static String lblCartItemAddedSuccessfully = "Your data has been updated";
  static String lblPrepDish = "Preparing Things for ordered dish";
  static String lblInKitchen = "Start Cooking for the dish";
  static String lblComplete = "Order Completed";
  static String lblChecked = "Completed";
  static String lblDineIn = "Dine-In";
  static String lblTakeAway = "Take Away";

  static String btnLogin = "Login";
  static String btnLogout = "Logout";
  static String btnForgot = "Forgot Password";
  static String btnRegister = "Register";
  static String btnExist = "Existing User";
  static String btnRegisterUser = "New User";
  static String btnSubmit = "Submit";
  static String btnAddMenu = "Add Menu";
  static String btnAddImage = "Add Image";
  static String btnPost = "Post Item";
  static String btnUser = "Coffee Lovers";
  static String btnStaff = "Coffee Makers";
  static String btnSearch = "Search";
  static String btnClear = "Clear";
  static String btnAddToWishlist = "Add to Wishlist";
  static String btnRemoveFromWishlist = "Remove from Wishlist";
  static String btnCheckout = "Checkout";
  static String btnRemoveItem = "Remove";
  static String btnRedeem = "Redeem";
  static String btnPay = "Pay Now";
  static String btnAddCode = "Add Code";
  static String btnRefresh = "Refresh";
  static String btnToday = "Today";
  static String btnServed = "Served";
  static String btnSet = "Set";
  static String btnFutureOrder = "Future Order";

  static String tabHome = "Home";
  static String tabMenu = "Menu";
  static String tabOrders = "Orders";

  // Tab Home label
  static String lblTotalOrders = "Total orders of the day";
  static String lblPendingOrders = "Pending Orders";

  static String loginScreen = "Existing User";
  static String registerScreen = "New User";
  static String forgotScreen = "Forgot Password";
  static String adminScreen = "Administrator Console";
  static String AddItemScreen = "Add Item";
  static String AlterItemScreen = "Modify Item";
  static String CartViewScreen = "Cart";
  static String WishItemScreen = "Wishlist";

  static String manipulatorKeyInput = "Enter";
  static String manipulatorKeyInvalid = "Invalid";

  static String msgPassInvalid =
      "The password length should be at least 8 characters";
  static String msgPassInvalidSimilar =
      "The confirm password should be same with password";
  static String msgAdminPassInvalid = "Invalid Password";
}
