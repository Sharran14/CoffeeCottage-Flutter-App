// ignore_for_file: prefer_final_fields, unused_field, empty_catches, unused_catch_clause, unused_local_variable, non_constant_identifier_names

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:forex_conversion/forex_conversion.dart';
import 'package:intl/intl.dart';
import 'package:toggle_switch/toggle_switch.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/model/cart_model.dart';
import 'package:uthmfoodie/model/promo_code_model.dart';
import 'package:uthmfoodie/model/user_order_model.dart';
import 'package:uthmfoodie/strings/strings.dart';
import 'package:uthmfoodie/util/payment.dart';

import '../global/colors.dart';

class CheckOutScreen extends StatefulWidget {
  final List<CartData> cartItem;
  const CheckOutScreen({required this.cartItem, super.key});

  @override
  State<CheckOutScreen> createState() => _CheckOutScreenState();
}

class _CheckOutScreenState extends State<CheckOutScreen> {
  final TextEditingController _specialOffer = TextEditingController();

  double _promoDiscount = 0.0, usd = 0.0;
  bool _isEnteredPromo = true;
  int _orderLevel = 0;
  String _lblFutureButton = Strings.btnFutureOrder, _selectedTimeString = "";
  TimeOfDay _selectedTime = TimeOfDay.now();

  PromoCodeData _promoCode =
      PromoCodeData(promoCode: "", price: 0, isActive: false);

  @override
  void dispose() {
    _specialOffer.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(Strings.btnCheckout),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    for (int i = 0; i < widget.cartItem.length; i++)
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.cartItem[i].itemName,
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 18.0),
                          ),
                          const SizedBox(height: 10.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                  "${Strings.lblPrice}: RM${widget.cartItem[i].itemPrice.toStringAsFixed(2)}"),
                              Text("x${widget.cartItem[i].itemQty}"),
                            ],
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                                "Discount: ${widget.cartItem[i].itemDiscount}%"),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              "Total Price: RM${widget.cartItem[i].totalItemPrice.toStringAsFixed(2)}",
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 40.0),
            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        decoration: InputDecoration(
                          border: const OutlineInputBorder(),
                          labelText: Strings.lblPromoCode,
                          labelStyle: TextStyle(color: CustomAppColor.primary),
                          floatingLabelStyle:
                              MaterialStateTextStyle.resolveWith(
                            (Set<MaterialState> states) {
                              final Color color =
                                  states.contains(MaterialState.error)
                                      ? Theme.of(context).colorScheme.error
                                      : CustomAppColor.primary;
                              return TextStyle(
                                  color: color, letterSpacing: 1.3);
                            },
                          ),
                        ),
                        autovalidateMode: AutovalidateMode.always,
                        keyboardType: TextInputType.name,
                        controller: _specialOffer,
                        enabled: _isEnteredPromo,
                      ),
                    ),
                    const SizedBox(width: 10.0),
                    SizedBox(
                      height: 60.0,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5.0)))),
                        onPressed: () => _getPriceFromPromo(),
                        child: Text(
                          Strings.btnRedeem,
                          style: TextStyle(color: CustomAppColor.secondary),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ToggleSwitch(
                      initialLabelIndex: 0,
                      totalSwitches: 2,
                      minWidth: 100.0,
                      inactiveBgColor: Colors.black,
                      activeBgColor: const [Color.fromRGBO(255, 253, 235, 1.0)],
                      activeFgColor: CustomAppColor.secondary,
                      labels: [Strings.lblDineIn, Strings.lblTakeAway],
                      onToggle: (index) {
                        _orderLevel = index!;
                      },
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(10.0),
                          ),
                        ),
                        backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                      ),
                      onPressed: () => _setTimeFuture(),
                      child: Text(
                        _lblFutureButton,
                        style: TextStyle(color: CustomAppColor.secondary),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("${Strings.lblPrice}:"),
                    Text("RM${_computeTotalPrice().toStringAsFixed(2)}"),
                  ],
                ),
                const SizedBox(height: 5.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("${Strings.lblDiscountPromo}:"),
                    Text(
                        "RM${(_promoCode.isActive ? _promoCode.price : 0).toStringAsFixed(2)}"),
                  ],
                ),
                const SizedBox(height: 5.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("${Strings.lblTotalPrice}:"),
                    Text(
                      "RM${_overallPrice().toStringAsFixed(2)}",
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 20.0),
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0)),
                    onPressed: () => _commit(),
                    child: Text(
                      Strings.btnPay,
                      style: TextStyle(color: CustomAppColor.secondary),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  _getTransId() {
    String day = DateFormat('EEEE').format(DateTime.now());
    String SerializeDay = "${day[0]}${day[2]}";
    SerializeDay = SerializeDay.toUpperCase();
    SerializeDay += DateFormat("ddMMyyyyHHmmssSSS").format(DateTime.now());
    return SerializeDay;
  }

  _computeTotalPrice() {
    double overallPrice = 0;
    for (CartData item in widget.cartItem) {
      overallPrice += item.totalItemPrice;
    }
    return overallPrice;
  }

  _getPriceFromPromo() async {
    await FirebaseFirestore.instance
        .collection("promos")
        .doc(_specialOffer.text)
        .get()
        .then(
          (value) => _getCodeValue(value),
        )
        .onError((error, stackTrace) => _setEmptyValue());
  }

  _overallPrice() {
    double price = _promoCode.price;
    if (_promoCode.isActive) {
      return _computeTotalPrice() - price < 0
          ? 0
          : _computeTotalPrice() - price;
    } else {
      return _computeTotalPrice();
    }
  }

  _getCodeValue(DocumentSnapshot<Map<String, dynamic>> value) {
    setState(() {
      _promoCode = PromoCodeData.fromDocumentSnapshot(value);
      _isEnteredPromo = _promoCode.isActive ? false : true;
      if (!_promoCode.isActive) {
        _setEmptyValue();
      }
    });
  }

  _setEmptyValue() {
    setState(() {
      _specialOffer.text = "";
    });
  }

  _commit() async {
    try {
      var orderCollection = FirebaseFirestore.instance.collection("orders");
      UserOrderData order = UserOrderData(
          orderId: _getTransId(),
          email: AuthController.getUserEmail(),
          promoCode: _promoCode.promoCode,
          promoDiscountPrice: _promoCode.price,
          totalPrice: _computeTotalPrice(),
          priceAfterDiscount: _overallPrice(),
          orderDate: DateTime.now(),
          isServed: false,
          servedTime: DateTime.now(),
          statusLevel: _orderLevel,
          isPaid: true,
          isPrep: false,
          isInKitchen: false,
          isComplete: false,
          orderTime: _selectedTimeString);

      await orderCollection
          .doc(order.orderId)
          .set(order.toMap())
          .then((value) => _addCartItemIntoCartList(order.orderId))
          .then((value) => _updateCartCollection())
          .then((value) => _paymentUpdte());
      // .then((value) =>
      //     Navigator.of(context).popUntil((route) => route.isFirst));
    } on FirebaseException catch (e) {}
  }

  _updateCartCollection() async {
    for (CartData cart in widget.cartItem) {
      await FirebaseFirestore.instance
          .collection("cart")
          .doc(cart.transId)
          .delete();
    }
  }

  _addCartItemIntoCartList(String orderId) async {
    var orderCollection = FirebaseFirestore.instance.collection("orders");

    for (CartData cart in widget.cartItem) {
      await orderCollection
          .doc(orderId)
          .collection("listOfCart")
          .doc(cart.transId)
          .set(cart.toMap());
    }
  }

  void _convert() async {
    final fx = Forex();

    final double myPriceInUSD = await fx.getCurrencyConverted(
        sourceCurrency: "MYR",
        destinationCurrency: "USD",
        sourceAmount: _overallPrice());
    setState(() {
      usd = myPriceInUSD;
    });
  }

  _paymentUpdte() {
    _convert();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (BuildContext context) => Payment(
          onFinish: (number) async {
            // payment done
            final snackBar = SnackBar(
              content: const Text("Payment done Successfully"),
              duration: const Duration(seconds: 5),
              action: SnackBarAction(
                label: 'Close',
                onPressed: () {
                  // Some code to undo the change.
                },
              ),
            );
            // _scaffoldKey.currentState!.showSnackBar(snackBar);
          },
        ),
      ),
    );
  }

  _setTimeFuture() async {
    var time =
        await showTimePicker(context: context, initialTime: _selectedTime);

    if (time != null) {
      setState(() {
        _selectedTime = time;
        String timeHour = time.hour.toString();
        String timeMinutes = time.minute.toString();
        _selectedTimeString =
            "${timeHour.padLeft(2, "0")}:${timeMinutes.padLeft(2, "0")}";
        _lblFutureButton = _selectedTimeString;
      });
    }
  }
}
