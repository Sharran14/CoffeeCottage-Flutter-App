// ignore_for_file: empty_catches, unused_catch_clause, prefer_typing_uninitialized_variables

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/model/detailed_user_data.dart';
import 'package:uthmfoodie/screens/user_page_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';

class UpdateUserDataScreen extends StatefulWidget {
  const UpdateUserDataScreen({super.key});

  @override
  State<UpdateUserDataScreen> createState() => _UpdateUserDataScreenState();
}

class _UpdateUserDataScreenState extends State<UpdateUserDataScreen> {
  late bool _isComplete;
  late var regDate;

  final TextEditingController _userFullName = TextEditingController();
  final TextEditingController _userNickName = TextEditingController();
  final TextEditingController _userPhoneName = TextEditingController();
  final _userCollection = FirebaseFirestore.instance.collection("user");

  @override
  void dispose() {
    _userFullName.dispose();
    _userNickName.dispose();
    _userPhoneName.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _fetchData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _bodyDecoration(),
    );
  }

  _bodyDecoration() {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.all(10.0),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: const AssetImage("images/splash_bg.png"),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.05),
              BlendMode.dstATop,
            ),
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 50.0),
            Text(
              Strings.lblUpdateAcc.toUpperCase(),
              style:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
            ),
            Text(Strings.lblUpdateAccDesc),
            const SizedBox(height: 100.0),
            TextFormField(
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: Strings.lblFullName,
                labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                  (Set<MaterialState> states) {
                    final Color color = states.contains(MaterialState.error)
                        ? Theme.of(context).colorScheme.error
                        : const Color.fromRGBO(255, 253, 235, 1.0);
                    return TextStyle(color: color, letterSpacing: 1.3);
                  },
                ),
              ),
              validator: (String? value) {
                if (value == null || value == '') {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInput} ${Strings.lblFullName}';
                }
                _isComplete = true;
                return null;
              },
              autovalidateMode: AutovalidateMode.always,
              keyboardType: TextInputType.text,
              controller: _userFullName,
            ),
            const SizedBox(height: 20.0),
            TextFormField(
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: Strings.lblNickName,
                labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                  (Set<MaterialState> states) {
                    final Color color = states.contains(MaterialState.error)
                        ? Theme.of(context).colorScheme.error
                        : const Color.fromRGBO(255, 253, 235, 1.0);
                    return TextStyle(color: color, letterSpacing: 1.3);
                  },
                ),
              ),
              validator: (String? value) {
                if (value == null || value == '') {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInput} ${Strings.lblNickName}';
                }
                _isComplete = true;
                return null;
              },
              autovalidateMode: AutovalidateMode.always,
              keyboardType: TextInputType.text,
              controller: _userNickName,
            ),
            const SizedBox(height: 20.0),
            TextFormField(
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: Strings.lblMobileNumber,
                labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                  (Set<MaterialState> states) {
                    final Color color = states.contains(MaterialState.error)
                        ? Theme.of(context).colorScheme.error
                        : const Color.fromRGBO(255, 253, 235, 1.0);
                    return TextStyle(color: color, letterSpacing: 1.3);
                  },
                ),
              ),
              validator: (String? value) {
                if (value == null || value == '') {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInput} ${Strings.lblMobileNumber}';
                }
                _isComplete = true;
                return null;
              },
              autovalidateMode: AutovalidateMode.always,
              keyboardType: TextInputType.number,
              controller: _userPhoneName,
            ),
            const SizedBox(height: 25.0),
            ElevatedButton(
                style: ElevatedButton.styleFrom(
                    fixedSize: Size(MediaQuery.of(context).size.width, 60)),
                onPressed: () => _commit(),
                child: Text(Strings.btnSubmit.toUpperCase()))
          ],
        ),
      ),
    );
  }

  _commit() {
    try {
      if (_isComplete) {
        DetailedUserData userData = DetailedUserData(
            fullname: _userFullName.text,
            nickname: _userNickName.text,
            phoneNumber: _userPhoneName.text,
            email: AuthController.getUserEmail(),
            dateJoined: regDate,
            isCompleted: true);
        _userCollection
            .doc(AuthController.getUserEmail())
            .set(userData.toMap())
            .then(
              (value) => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (BuildContext context) => const UserPageScreen(),
                ),
              ),
            );
      }
    } on FirebaseException catch (e) {}
  }

  _fetchData() async {
    await _userCollection
        .doc(AuthController.getUserEmail())
        .get()
        .then((value) => setState(() {
              regDate = value["dateJoined"].toDate();
            }));
  }
}
