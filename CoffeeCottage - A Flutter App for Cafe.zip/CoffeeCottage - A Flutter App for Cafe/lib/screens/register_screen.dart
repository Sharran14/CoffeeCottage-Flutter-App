// ignore_for_file: use_build_context_synchronously, await_only_futures

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/model/basic_user_data.dart';
import 'package:uthmfoodie/screens/forgot_screen.dart';
import 'package:uthmfoodie/screens/login_screen.dart';
import 'package:uthmfoodie/screens/main_auth_launcher_screen.dart';
import 'package:uthmfoodie/screens/update_user_data_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';
import 'package:uthmfoodie/util/system_defaults.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController _userEmailInput = TextEditingController();
  final TextEditingController _userPasswordInput = TextEditingController();
  final TextEditingController _userConfPasswordInput = TextEditingController();

  late bool _isComplete;

  @override
  void dispose() {
    _userEmailInput.dispose();
    _userPasswordInput.dispose();
    _userConfPasswordInput.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) {
        if (didPop) {
          return;
        }
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) => const MainAuthLauncherScreen(),
          ),
        );
      },
      child: Scaffold(
         resizeToAvoidBottomInset: false,
        extendBodyBehindAppBar: true,
        body: SingleChildScrollView(
          child: _bodyDecoration(),
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
          onPressed: () => _commit(),
          label: Text(
            Strings.btnRegister.toUpperCase(),
            style: TextStyle(color: CustomAppColor.secondary),
          ),
          icon: Icon(Icons.check, color: CustomAppColor.secondary),
        ),
      ),
    );
  }

  _bodyDecoration() {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.all(10.0),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: const AssetImage("images/splash_bg.png"),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.05),
              BlendMode.dstATop,
            ),
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 50.0),
            Text(
              Strings.lblCreateAcc.toUpperCase(),
              style:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
            ),
            Text(Strings.lblCreateAccDesc),
            const SizedBox(height: 100.0),
            TextFormField(
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: Strings.lblEmail,
                labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                  (Set<MaterialState> states) {
                    final Color color = states.contains(MaterialState.error)
                        ? Theme.of(context).colorScheme.error
                        : const Color.fromRGBO(255, 253, 235, 1.0);
                    return TextStyle(color: color, letterSpacing: 1.3);
                  },
                ),
              ),
              validator: (String? value) {
                if (value == null || value == '') {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInput} ${Strings.lblEmail}';
                } else if (!RegExp(
                        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                    .hasMatch(value)) {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInvalid} ${Strings.lblEmail}';
                }
                _isComplete = true;
                return null;
              },
              autovalidateMode: AutovalidateMode.always,
              controller: _userEmailInput,
            ),
            const SizedBox(height: 20.0),
            TextFormField(
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: Strings.lblPassword,
                labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                  (Set<MaterialState> states) {
                    final Color color = states.contains(MaterialState.error)
                        ? Theme.of(context).colorScheme.error
                        : const Color.fromRGBO(255, 253, 235, 1.0);
                    return TextStyle(color: color, letterSpacing: 1.3);
                  },
                ),
              ),
              validator: (String? value) {
                if (value == null || value == '') {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInput} ${Strings.lblPassword}';
                } else if (value.length < 8) {
                  _isComplete = false;
                  return Strings.msgPassInvalid;
                }
                _isComplete = true;
                return null;
              },
              autovalidateMode: AutovalidateMode.always,
              controller: _userPasswordInput,
              obscureText: true,
              autocorrect: false,
            ),
            const SizedBox(height: 20.0),
            TextFormField(
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: Strings.lblConfPassword,
                labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                  (Set<MaterialState> states) {
                    final Color color = states.contains(MaterialState.error)
                        ? Theme.of(context).colorScheme.error
                        : const Color.fromRGBO(255, 253, 235, 1.0);
                    return TextStyle(color: color, letterSpacing: 1.3);
                  },
                ),
              ),
              validator: (String? value) {
                if (value == null || value == '') {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInput} ${Strings.lblPassword}';
                } else if (value.length < 8) {
                  _isComplete = false;
                  return Strings.msgPassInvalid;
                } else if (_userPasswordInput.text !=
                    _userConfPasswordInput.text) {
                  _isComplete = false;
                  return Strings.msgPassInvalidSimilar;
                }
                _isComplete = true;
                return null;
              },
              autovalidateMode: AutovalidateMode.always,
              controller: _userConfPasswordInput,
              obscureText: true,
              autocorrect: false,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (BuildContext context) =>
                          const LoginScreen(isAdmin: false),
                    ),
                  ),
                  child: Text(Strings.btnExist.toUpperCase()),
                ),
                TextButton(
                  onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (BuildContext context) =>
                          const ForgotPasswordScreen(),
                    ),
                  ),
                  child: Text(Strings.btnForgot.toUpperCase()),
                ),
              ],
            ),
            const SizedBox(height: 25.0),
          ],
        ),
      ),
    );
  }

  _commit() async {
    if (_isComplete) {
      try {
        FirebaseAuth auth = await FirebaseAuth.instance;
        auth
            .createUserWithEmailAndPassword(
                email: _userEmailInput.text.trim(),
                password: _userPasswordInput.text.trim())
            .then((value) => _processRegistration())
            .onError((error, stackTrace) => SystemDefaults.showSnackBar(
                context: context, msg: error.toString(), duration: 5));
      } on FirebaseAuthException catch (e) {
        SystemDefaults.showSnackBar(
            context: context, msg: e.message.toString(), duration: 5);
      }
    } else {
      return;
    }
  }

  _processRegistration() {
    BasicUserData newUserData = BasicUserData(
        email: AuthController.getUserEmail(),
        dateJoined: DateTime.now(),
        isCompleted: false);
    var userCollection = FirebaseFirestore.instance.collection("user");
    try {
      userCollection
          .doc(newUserData.email)
          .set(newUserData.toMap())
          .then((value) => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (BuildContext context) =>
                      const UpdateUserDataScreen(),
                ),
              ));
    } on FirebaseException catch (e) {
      SystemDefaults.showSnackBar(
          context: context, msg: e.message.toString(), duration: 5);
    }
  }
}
