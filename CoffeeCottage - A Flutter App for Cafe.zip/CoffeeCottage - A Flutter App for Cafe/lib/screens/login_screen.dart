// ignore_for_file: unused_catch_clause, non_constant_identifier_names, use_build_context_synchronously

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/screens/admin_page_screen.dart';
import 'package:uthmfoodie/screens/forgot_screen.dart';
import 'package:uthmfoodie/screens/main_auth_launcher_screen.dart';
import 'package:uthmfoodie/screens/register_screen.dart';
import 'package:uthmfoodie/screens/update_user_data_screen.dart';
import 'package:uthmfoodie/screens/user_page_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';
import 'package:uthmfoodie/util/system_defaults.dart';

class LoginScreen extends StatefulWidget {
  final bool isAdmin;
  const LoginScreen({super.key, required this.isAdmin});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _userEmailInput = TextEditingController();
  final TextEditingController _userPasswordInput = TextEditingController();

  late bool _isComplete;

  @override
  void dispose() {
    _userEmailInput.dispose();
    _userPasswordInput.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) {
        if (didPop) {
          return;
        }
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) => const MainAuthLauncherScreen(),
          ),
        );
      },
      child: Scaffold(
         resizeToAvoidBottomInset: false,
        extendBodyBehindAppBar: true,
        body: SingleChildScrollView(
          child: _bodyDecoration(context),
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
          onPressed: () => _commit(),
          label: Text(
            Strings.btnLogin.toUpperCase(),
            style: TextStyle(color: CustomAppColor.secondary),
          ),
          icon: Icon(
            Icons.send,
            color: CustomAppColor.secondary,
          ),
        ),
      ),
    );
  }

  _bodyDecoration(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(15.0),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: const AssetImage("images/splash_bg.png"),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.05),
              BlendMode.dstATop,
            ),
          ),
        ),
        child: ListView(
          children: [

                Image.asset(
                  "images/outline_cc.png",
                  
                  height: 150.0,
                ),
             const SizedBox(height: 20.0),

            Text(
              widget.isAdmin
                  ? Strings.lblStaffLogin.toUpperCase()
                  : Strings.lblUserLogin.toUpperCase(),
              style:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 10.0),
            ),
            const SizedBox(height: 20.0),
            TextFormField(
              decoration: InputDecoration(
                border: const OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.greenAccent, width: 5.0)
                ),
                
                labelText: Strings.lblEmail,
                labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                  (Set<MaterialState> states) {
                    final Color color = states.contains(MaterialState.error)
                        ? Theme.of(context).colorScheme.onError
                        : const Color.fromRGBO(255, 253, 235, 1.0);
                    return TextStyle(color: color, letterSpacing: 1.3);
                  },
                ),
              ),
              validator: (String? value) {
                if (value == null || value == '') {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInput} ${Strings.lblEmail}';
                } else if (!RegExp(
                        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                    .hasMatch(value)) {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInvalid} ${Strings.lblEmail}';
                }
                _isComplete = true;
                return null;
              },
              autovalidateMode: AutovalidateMode.always,
              controller: _userEmailInput,
            ),
            const SizedBox(height: 20.0),
            TextFormField(
              decoration: InputDecoration(
                fillColor: Colors.white,
                border: const OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white, width: 2.0),
             //   borderRadius: BorderRadius.circular(25.0),
                ),
                labelText: Strings.lblPassword,
                labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                  (Set<MaterialState> states) {
                    final Color color = states.contains(MaterialState.error)
                        ? Theme.of(context).colorScheme.onError
                        : const Color.fromRGBO(255, 253, 235, 1.0);
                    return TextStyle(color: color, letterSpacing: 1.3);
                  },
                ),
              ),
              validator: (String? value) {
                if (value == null || value == '') {
                  _isComplete = false;
                  return '${Strings.manipulatorKeyInput} ${Strings.lblPassword}';
                } else if (value.length < 8) {
                  _isComplete = false;
                  return Strings.msgPassInvalid;
                }
                _isComplete = true;
                return null;
              },
              autovalidateMode: AutovalidateMode.always,
              controller: _userPasswordInput,
              obscureText: true,
              autocorrect: false,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Visibility(
                  visible: !widget.isAdmin,
                  child: TextButton(
                    onPressed: () => Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (BuildContext context) =>
                            const RegisterScreen(),
                      ),
                    ),
                    child: Text(Strings.btnRegisterUser.toUpperCase()),
                  ),
                ),
                Visibility(
                  visible: !widget.isAdmin,
                  child: TextButton(
                    onPressed: () => Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (BuildContext context) =>
                            const ForgotPasswordScreen(),
                      ),
                    ),
                    child: Text(Strings.btnForgot.toUpperCase()),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 25.0),
          ],
        ),
      ),
    );
  }

  _commit() async {
    if (_isComplete) {
      try {
        FirebaseAuth auth = await FirebaseAuth.instance;
        auth
            .signInWithEmailAndPassword(
                email: _userEmailInput.text.trim(),
                password: _userPasswordInput.text.trim())
            .then((value) => _navigateToPage())
            .onError(
                (error, stackTrace) => AlertUser("Error", error.toString()));
      } on FirebaseAuthException catch (e) {
        _showErrorMessage(e.message);
      }
    } else {
      return;
    }
  }

  void AlertUser(String header, String body) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(header),
        content: Text(body),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  _showErrorMessage(String? message) {
    SystemDefaults.showSnackBar(
        context: context, msg: message.toString(), duration: 5);
  }

  _navigateToPage() async {
    var userCollection = FirebaseFirestore.instance.collection("user");
    bool isMeetCond = false;
    try {
      if (!widget.isAdmin) {
        await userCollection
            .doc(AuthController.getUserEmail())
            .get()
            .then((value) => isMeetCond = value["isCompleted"]);
      }
      var page = widget.isAdmin
          ? const AdminPageScreen()
          : isMeetCond
              ? const UserPageScreen()
              : const UpdateUserDataScreen();
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (BuildContext context) => page));
    } on FirebaseException catch (e) {
      //TODO do nothing for now
    }
  }
}
