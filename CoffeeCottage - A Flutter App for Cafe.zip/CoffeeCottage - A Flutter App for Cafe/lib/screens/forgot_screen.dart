// ignore_for_file: unused_import, await_only_futures

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:uthmfoodie/screens/login_screen.dart';
import 'package:uthmfoodie/screens/main_auth_launcher_screen.dart';
import 'package:uthmfoodie/screens/register_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';
import 'package:uthmfoodie/util/system_defaults.dart';
import 'package:uthmfoodie/global/colors.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final TextEditingController _userEmailInput = TextEditingController();

  late bool _isComplete;

  @override
  void dispose() {
    _userEmailInput.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) {
        if (didPop) {
          return;
        }
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) => const MainAuthLauncherScreen(),
          ),
        );
      },
      child: Scaffold(
         resizeToAvoidBottomInset: false,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
        ),
        body: SingleChildScrollView(
          child: _bodyDecoration(),
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
          onPressed: () => _commit(),
          label: Text(
            Strings.btnSubmit.toUpperCase(),
            style: const TextStyle(color: Color(0xff533c1c)),
          ),
          icon: const Icon(
            Icons.send,
            color: Color(0xff533c1c),
          ),
        ),
      ),
    );
  }

  _bodyDecoration() {
    return Container(
      padding: const EdgeInsets.all(10.0),
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: const AssetImage("images/splash_bg.png"),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(
            Colors.black.withOpacity(0.05),
            BlendMode.dstATop,
          ),
        ),
      ),
      child: Column(
        children: [
          const SizedBox(height: 50.0),
          Text(
            Strings.lblForgotPassTitle.toUpperCase(),
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
          ),
          Text(Strings.lblForgotPassTitleDesc),
          const SizedBox(height: 100.0),
          TextFormField(
            decoration: InputDecoration(
              border: const OutlineInputBorder(),
              labelText: Strings.lblEmail,
              labelStyle: const TextStyle(color:  Color.fromRGBO(255, 253, 235, 1.0)),
              floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                (Set<MaterialState> states) {
                  final Color color = states.contains(MaterialState.error)
                      ? Theme.of(context).colorScheme.error
                      : const Color.fromRGBO(255, 253, 235, 1.0);
                  return TextStyle(color: color, letterSpacing: 1.3);
                },
              ),
            ),
            validator: (String? value) {
              if (value == null || value == '') {
                _isComplete = false;
                return '${Strings.manipulatorKeyInput} ${Strings.lblEmail}';
              } else if (!RegExp(
                      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                  .hasMatch(value)) {
                _isComplete = false;
                return '${Strings.manipulatorKeyInvalid} ${Strings.lblEmail}';
              }
              _isComplete = true;
              return null;
            },
            autovalidateMode: AutovalidateMode.always,
            controller: _userEmailInput,
          ),
          Row(
            children: [
              TextButton(
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) =>
                        const LoginScreen(isAdmin: false),
                  ),
                ),
                child: Text(Strings.btnExist.toUpperCase()),
              ),
              const Expanded(
                child: SizedBox(width: 10.0),
              ),
              TextButton(
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) => const RegisterScreen(),
                  ),
                ),
                child: Text(Strings.btnRegisterUser.toUpperCase()),
              ),
            ],
          ),
          const SizedBox(height: 25.0),
        ],
      ),
    );
  }

  _commit() async {
    if (_isComplete) {
      try {
        FirebaseAuth auth = await FirebaseAuth.instance;
        auth
            .sendPasswordResetEmail(email: _userEmailInput.text.trim())
            .whenComplete(() => _navigateToPage());
      } on FirebaseAuthException catch (e) {
        dummyMethod(e.message);
      }
    } else {
      return;
    }
  }

  dummyMethod(String? message) {
    SystemDefaults.showSnackBar(
        context: context, msg: message.toString(), duration: 5);
  }

  _navigateToPage() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => const LoginScreen(isAdmin: false),
      ),
    );
  }
}
