import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/model/user_order_model.dart';
import 'package:uthmfoodie/screens/user_order_instances_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';

class UserCompleteOrderHistoryScreen extends StatefulWidget {
  const UserCompleteOrderHistoryScreen({super.key});

  @override
  State<UserCompleteOrderHistoryScreen> createState() =>
      _UserCompleteOrderHistoryScreenState();
}

class _UserCompleteOrderHistoryScreenState
    extends State<UserCompleteOrderHistoryScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(Strings.lblOrderHistory),
      ),
      body: Container(
        padding: const EdgeInsets.all(10.0),
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection("orders")
              .where("email", isEqualTo: AuthController.getUserEmail())
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return ListView.builder(
                  itemCount: snapshot.data!.docs.length,
                  itemBuilder: (context, index) {
                    UserOrderData orderData =
                        UserOrderData.fromDocumentSnapshot(
                            snapshot.data!.docs[index]);
                    return InkWell(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext ctx) =>
                              UserOrderInstanceScreen(
                                  OrderId: orderData.orderId),
                        ),
                      ),
                      child: Card(
                        child: Container(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 35.0,
                                backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                                child: Container(
                                  padding: const EdgeInsets.all(10.0),
                                  child:
                                      Image.asset("images/dish_completed.png"),
                                ),
                              ),
                              const SizedBox(width: 20.0),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(orderData.orderId),
                                  const SizedBox(height: 8.0),
                                  Text(
                                      "Date: ${DateFormat("dd/MM/yyyy").format(orderData.orderDate)}"),
                                  Text(
                                    "Total Amount Spent: RM${orderData.priceAfterDiscount.toStringAsFixed(2)}",
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold),
                                  )
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  });
            }
            return Center(
              child: Text(Strings.lblNoOrders),
            );
          },
        ),
      ),
    );
  }
}
