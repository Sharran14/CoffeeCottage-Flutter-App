import 'package:flutter/material.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/screens/login_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';

class MainAuthLauncherScreen extends StatelessWidget {
  const MainAuthLauncherScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       resizeToAvoidBottomInset: false,
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/splash_bg.png"),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Color.fromRGBO(35, 29, 28, 0.08),
              BlendMode.dstATop,
            ),
          ),
        ),

        child: Stack(
          children: [
          Image.asset(
              "images/header1.png",
              fit: BoxFit.fitWidth,
            ),
        Positioned(
        child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            const SizedBox(height: 280),
            ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        fixedSize: const Size(180, 0),
                      ),
                      onPressed: () => _authPage("staff", context),
                      child: Text(
                        Strings.btnStaff.toUpperCase(),
                        style: TextStyle(color: CustomAppColor.secondary),
                      ),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(50.0),
                          ),
                          fixedSize: const Size(180, 0)),
                      onPressed: () => _authPage("user", context),
                      child: Text(
                        Strings.btnUser.toUpperCase(),
                        style: TextStyle(color: CustomAppColor.secondary),
                      ),
                    ),
          // const SizedBox(height: 200), 
            Align(
              alignment: Alignment.centerLeft,
             // alignment: Alignment.bottomLeft,
                child: Image.asset(
                "images/bottom_logo.png",
                height: 200.0,
                
              ),   
                
            ),
          ],
        ),
        )
        ),
        ],
      ),
      ),
    );
  }
  _authPage(String userType, BuildContext context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) =>
            LoginScreen(isAdmin: userType == "staff" ? true : false),
      ),
    );
  }
}
