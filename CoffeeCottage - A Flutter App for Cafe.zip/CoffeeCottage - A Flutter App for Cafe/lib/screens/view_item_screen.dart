// ignore_for_file: unused_field, await_only_futures, prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:elegant_notification/elegant_notification.dart';
import 'package:elegant_notification/resources/stacked_options.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/model/cart_model.dart';
import 'package:uthmfoodie/model/wish_data.dart';
import 'package:uthmfoodie/screens/admin_page_screen.dart';
import 'package:uthmfoodie/screens/cart_view_screen.dart';
import 'package:uthmfoodie/screens/user_page_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';

class ViewItemScreen extends StatefulWidget {
  final String productName;
  const ViewItemScreen({super.key, required this.productName});

  @override
  State<ViewItemScreen> createState() => _ViewItemScreenState();
}

class _ViewItemScreenState extends State<ViewItemScreen> {
  String _itemName = "",
      _itemDescription = "",
      _itemNutrition = "",
      _itemURL = "";
  double _itemPrice = 0.0, _itemDiscount = 0.0;
  int numberOfOrders = 0, _itemAvailability = 0;
  var _favIcon = Icons.favorite_outline_rounded;
  String _wishLabel = Strings.btnAddToWishlist;
  late WishData _currWish;
  @override
  void initState() {
    _fetchItemData();
    _manageWishList(event: "onLoad");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) {
        if (didPop) {
          return;
        }

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) =>
                AuthController.getUserEmail() != "admin@test.com"
                    ? const UserPageScreen()
                    : const AdminPageScreen(),
          ),
        );
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (BuildContext ctx) =>
                    AuthController.getUserEmail() != "admin@test.com"
                        ? const UserPageScreen()
                        : const AdminPageScreen(),
              ),
            ),
          ),
          title: Text(widget.productName),
        ),
        body: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.network(
                  _itemURL,
                  fit: BoxFit.cover,
                  height: MediaQuery.of(context).size.width,
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.0),
                        child: Text(
                          _itemName,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 25.0),
                        ),
                      ),
                      Text(_itemDescription, softWrap: true),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          "RM ${_itemPrice.toStringAsFixed(2)}",
                          style: const TextStyle(
                              fontSize: 18.0, fontWeight: FontWeight.bold),
                        ),
                      ),
                      Visibility(
                        visible:
                            AuthController.getUserEmail() == "admin@test.com"
                                ? true
                                : false,
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                            margin: const EdgeInsets.only(top: 10.0),
                            decoration: BoxDecoration(
                              color: CustomAppColor.primary,
                              borderRadius: const BorderRadius.all(
                                Radius.circular(8.0),
                              ),
                            ),
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                    "Discount: ${_itemDiscount.toStringAsFixed(1)}%"),
                                Text("Total Availability: $_itemAvailability"),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20.0),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Visibility(
                          visible:
                              AuthController.getUserEmail() != "admin@test.com"
                                  ? true
                                  : false,
                          child: ElevatedButton.icon(
                            onPressed: () =>
                                _manageWishList(event: "onTriggered"),
                            icon: Icon(_favIcon),
                            label: Text(_wishLabel),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20.0, bottom: 5.0),
                        child: Text(
                          Strings.lblItemNutrition,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16.0),
                        ),
                      ),
                      Text(_itemNutrition),
                      const SizedBox(height: 50.0),
                      Visibility(
                        visible:
                            AuthController.getUserEmail() != "admin@test.com"
                                ? true
                                : false,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(Strings.lblNumberOfOrders),
                            Container(
                              width: 120.0,
                              padding: const EdgeInsets.all(8.0),
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(color: Colors.grey.shade500),
                                  borderRadius: BorderRadius.circular(5.0)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  InkWell(
                                    onTap: () => setState(() {
                                      numberOfOrders++;
                                    }),
                                    child: const Icon(
                                      Icons.add,
                                      size: 18.0,
                                    ),
                                  ),
                                  Text(numberOfOrders.toString()),
                                  InkWell(
                                    onTap: () => setState(() {
                                      numberOfOrders--;
                                    }),
                                    child: const Icon(
                                      Icons.remove,
                                      size: 18.0,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        floatingActionButton: Visibility(
          visible:
              AuthController.getUserEmail() != "admin@test.com" ? true : false,
          child: FloatingActionButton.extended(
            backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
            onPressed: () => _addToCart(),
            icon: Icon(
              Icons.shopping_cart,
              color: CustomAppColor.secondary,
            ),
            label: Text(
              Strings.lblAddToCart,
              style: TextStyle(color: CustomAppColor.secondary),
            ),
          ),
        ),
      ),
    );
  }

  _fetchItemData() async {
    var sellerCollection = FirebaseFirestore.instance.collection("seller");
    await sellerCollection
        .doc(widget.productName)
        .get()
        .then((value) => setState(() {
              _itemName = value["itemName"];
              _itemDescription = value["itemDescription"];
              _itemNutrition = value["itemNutrition"];
              _itemURL = value["itemImage"];
              _itemPrice = value["itemPrice"];
              _itemDiscount = value["itemDiscount"];
              _itemAvailability = value["itemAvailabilityPerOrder"];
            }));
  }

  _manageWishList({required String event}) async {
    var wishCollection = FirebaseFirestore.instance
        .collection("seller")
        .doc(widget.productName)
        .collection("wishlist");

    await wishCollection
        .where("email", isEqualTo: AuthController.getUserEmail())
        .get()
        .then((value) => _addDataToWish(value, wishCollection, event));
  }

  _addDataToWish(
      QuerySnapshot<Map<String, dynamic>> value,
      CollectionReference<Map<String, dynamic>> wishCollection,
      String event) async {
    if (event == "onLoad") {
      if (value.size > 0) {
        setState(() {
          _favIcon = Icons.favorite_rounded;
          _wishLabel = Strings.btnRemoveFromWishlist;
        });
      }
    } else {
      if (value.size == 0) {
        String id = await wishCollection.doc().id;
        WishData wishlist =
            WishData(uid: id, email: AuthController.getUserEmail());
        await wishCollection.doc(id).set(wishlist.toMap()).then(
              (value) => setState(() {
                _favIcon = Icons.favorite_rounded;
                _wishLabel = Strings.btnRemoveFromWishlist;
              }),
            );
      } else {
        WishData wishlist = WishData.fromDocumentSnapshot(value.docs.first);
        await wishCollection.doc(wishlist.uid).delete().then(
              (value) => setState(() {
                _favIcon = Icons.favorite_border_rounded;
                _wishLabel = Strings.btnAddToWishlist;
              }),
            );
      }
    }
  }

  _addToCart() async {
    var cartCollection = FirebaseFirestore.instance.collection("cart");
    int totalOrder = numberOfOrders == 0 ? 1 : numberOfOrders;
    CartData cart;

    await cartCollection
        .where("email", isEqualTo: AuthController.getUserEmail())
        .where("itemName", isEqualTo: _itemName)
        .get()
        .then((value) async {
      if (value.size == 0) {
        String transId = DateFormat("yyyyMMddHHmmssSSS").format(DateTime.now());
        cart = CartData(
            transId: transId,
            email: AuthController.getUserEmail(),
            itemName: _itemName,
            itemQty: totalOrder,
            itemPrice: _itemPrice,
            itemDiscount: _itemDiscount,
            totalItemPrice: _getItemQty(totalOrder, _itemPrice, _itemDiscount));
        await cartCollection
            .doc(cart.transId)
            .set(cart.toMap())
            .then((value) => _showNotification());
      } else {
        cart = CartData.fromDocumentSnapshot(value.docs.first);
        cart.itemQty += totalOrder;
        cart.totalItemPrice =
            _getItemQty(cart.itemQty, cart.itemPrice, cart.itemDiscount);
        await cartCollection
            .doc(cart.transId)
            .update(cart.toMap())
            .then((value) => _showNotification());
      }
    });
  }

  _getItemQty(int qty, double itemPrice, double itemDiscount) {
    return (itemPrice - (itemPrice * (itemDiscount / 100))) * qty;
  }

  _showNotification() {
    ElegantNotification.success(
      background: const Color(0xFF141414),
      width: 360,
      shadow: BoxShadow(
        color: Colors.black.withOpacity(0.15),
        spreadRadius: 5,
        blurRadius: 10,
        offset: Offset(0, 2),
      ),
      isDismissable: true,
      stackedOptions: StackedOptions(
        key: 'top',
        type: StackedType.same,
        itemOffset: const Offset(-5, 20),
      ),
      title: Text(Strings.lblCartTitle),
      description: Text(Strings.lblCartItemAddedSuccessfully),
      onDismiss: () {
        Navigator.pop(context);
      },
      onNotificationPressed: () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) => CartViewScreen(),
          ),
        );
      },
      border: const Border(
        bottom: BorderSide(
          color: Colors.green,
          width: 2,
        ),
      ),
    ).show(context);
  }
}
