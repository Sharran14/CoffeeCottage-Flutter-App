import 'package:flutter/material.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/screens/main_auth_launcher_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';
import 'package:uthmfoodie/views/home_view.dart';
import 'package:uthmfoodie/views/menu_view.dart';
import 'package:uthmfoodie/views/orders_view.dart';

class AdminPageScreen extends StatefulWidget {
  const AdminPageScreen({super.key});

  @override
  State<AdminPageScreen> createState() => _AdminPageScreenState();
}

class _AdminPageScreenState extends State<AdminPageScreen> {
  var pages = [const HomeView(), const MenuView(), const OrdersView()];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(Strings.appName),
          actions: [
            PopupMenuButton<int>(
              onSelected: (item) => _handleClick(item),
              itemBuilder: (context) => [
                const PopupMenuItem<int>(value: 0, child: Text('Logout')),
              ],
            ),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(
                text: "Home",
              ),
              Tab(
                text: "Menu",
              ),
              Tab(
                text: "Orders",
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: pages,
        ),
      ),
    );
  }

  _handleClick(int item) {
    switch (item) {
      case 0:
        AuthController.signOut();
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (BuildContext context) => const MainAuthLauncherScreen(),
          ),
        );
    }
  }
}
