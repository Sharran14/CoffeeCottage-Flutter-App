// ignore_for_file: unnecessary_null_comparison, prefer_final_fields, unused_field, no_leading_underscores_for_local_identifiers, unused_element, avoid_function_literals_in_foreach_calls, prefer_interpolation_to_compose_strings, avoid_print

import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/model/food_menu.dart';
import 'package:uthmfoodie/screens/cart_view_screen.dart';
import 'package:uthmfoodie/screens/current_order_screen.dart';
import 'package:uthmfoodie/screens/main_auth_launcher_screen.dart';
import 'package:uthmfoodie/screens/user_order_history.dart';
import 'package:uthmfoodie/screens/view_item_screen.dart';
import 'package:uthmfoodie/screens/wish_item_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';

class UserPageScreen extends StatefulWidget {
  const UserPageScreen({super.key});

  @override
  State<UserPageScreen> createState() => _UserPageScreenState();
}

class _UserPageScreenState extends State<UserPageScreen>
    with SingleTickerProviderStateMixin {
  var sellerCollection = FirebaseFirestore.instance.collection('seller');
  String _searchKey = "";
  final TextEditingController _itemSearch = TextEditingController();
  late TabController _controller;
  int _selectedIndex = 0;
  bool _isDoneGreetings = false;

  var _menu = [];
  int wishCount = 0, cartCount = 0;

  @override
  void dispose() {
    _itemSearch.dispose();
    super.dispose();
  }

  @override
  initState() {
    _fetchMenuItem();
    _getCountWish();
    _getCountCartUser();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Image.asset("images/outline_cc.png"),
        title: Text(Strings.appNameShort),
        actions: [
          Stack(
            children: [
              IconButton(
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext ctx) => const WishItemScreen(),
                  ),
                ),
                icon: const Icon(Icons.favorite),
              ),
              Positioned(
                child: CircleAvatar(
                  radius: 10.0,
                  backgroundColor: Colors.red,
                  child: Text(
                    wishCount.toString(),
                    style: const TextStyle(color: Colors.white, fontSize: 10),
                  ),
                ),
              ),
            ],
          ),
          Stack(
            children: [
              IconButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext ctx) => const CartViewScreen(),
                  ),
                ),
                icon: const Icon(Icons.shopping_cart),
              ),
              Positioned(
                child: CircleAvatar(
                  radius: 10.0,
                  backgroundColor: Colors.red,
                  child: Text(
                    cartCount.toString(),
                    style: const TextStyle(color: Colors.white, fontSize: 10),
                  ),
                ),
              ),
            ],
          ),
          PopupMenuButton<int>(
            onSelected: (item) => _handleClick(item),
            itemBuilder: (context) => [
              PopupMenuItem<int>(value: 0, child: Text(Strings.lblLogout)),
              PopupMenuItem<int>(
                  value: 1, child: Text(Strings.lblCurrentOrderStatus)),
              PopupMenuItem<int>(
                  value: 2, child: Text(Strings.lblOrderHistory)),
            ],
          ),
        ],
        bottom: TabBar(
          controller: _controller,
          onTap: (index) {
            // Should not used it as it only called when tab options are clicked,
            // not when user swapped
          },
          tabs: [
            for (int i = 0; i < _menu.length; i++) Tab(text: _menu[i]),
          ],
        ),
      ),
      body: TabBarView(
        controller: _controller,
        children: [
          _menuContent(),
        ],
      ),
    );
  }

  _handleClick(int item) {
    switch (item) {
      case 0:
        AuthController.signOut();
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (BuildContext context) => const MainAuthLauncherScreen(),
          ),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) => const CurrentOrderStatus(),
          ),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) =>
                const UserCompleteOrderHistoryScreen(),
          ),
        );
        break;
    }
  }

  Stream<QuerySnapshot> stream() async* {
    var _stream = sellerCollection.snapshots();
    yield* _stream;
  }

  Stream<QuerySnapshot> searchData(String string) async* {
    var _search =
        sellerCollection.where('itemName', isEqualTo: string).snapshots();

    yield* _search;
  }

  _customStrem() {
    if (_searchKey != null || _searchKey.isNotEmpty) {
      sellerCollection.where('itemName', isEqualTo: _searchKey).snapshots();
    }
    return sellerCollection.snapshots();
  }

  _itemCard(FoodMenu foodMenu) {
    return Card(
      elevation: 5,
      child: Container(
        padding: const EdgeInsets.all(10.0),
        height: 100.0,
        child: Row(
          children: [
            Container(
              width: 80.0,
              height: 80.0,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(
                  Radius.circular(10.0),
                ),
                image: DecorationImage(
                    image: NetworkImage(foodMenu.itemImage), fit: BoxFit.cover),
              ),
            ),
            const SizedBox(width: 10.0),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 10.0),
                  Text(
                    foodMenu.itemName,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Text(
                      foodMenu.itemDescription,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Text(
                    "Nutrition: ${foodMenu.itemNutrition}",
                    overflow: TextOverflow.ellipsis,
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  _setChanges() {
    setState(() {
      _searchKey = _itemSearch.text;
    });
  }

  _fetchMenuItem() async {
    List<FoodMenu> items = [];
    List<String> menuItem = [];

    await FirebaseFirestore.instance.collection("seller").get().then(
          (value) => setState(() {
            items = value.docs.map((e) => FoodMenu.fromMap(e.data())).toList();
          }),
        );

    items.forEach((element) {
      menuItem.add(element.itemType);
    });
    setState(() {
      _menu = menuItem.toSet().toList();
    });
    // Create TabController for getting the index of current tab
    _controller = TabController(length: _menu.length, vsync: this);

    _controller.addListener(() {
      setState(() {
        _selectedIndex = _controller.index;
      });
      print("Selected Index: " + _controller.index.toString());
    });
  }

  _menuContent() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10.0),
          child: Card(
            elevation: 5.0,
            child: Container(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                children: [
                  TextField(
                    autocorrect: true,
                    controller: _itemSearch,
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        hintText: Strings.lblSearch),
                  ),
                  const SizedBox(height: 10.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Expanded(
                        child: SizedBox(
                          width: 10.0,
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0)),
                        onPressed: () => setState(() {
                          _searchKey = "";
                          _itemSearch.text = "";
                        }),
                        child: Text(
                          Strings.btnClear,
                          style: TextStyle(color: CustomAppColor.secondary),
                        ),
                      ),
                      const SizedBox(width: 10.0),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0)),
                        onPressed: () => _setChanges(),
                        child: Text(
                          Strings.btnSearch,
                          style: TextStyle(color: CustomAppColor.secondary),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: StreamBuilder(
              stream: _searchKey == null || _searchKey.isEmpty
                  ? sellerCollection
                      .where("itemAvailabilityPerOrder", isGreaterThan: 0)
                      .snapshots()
                  : sellerCollection
                      .where('itemName', isEqualTo: _searchKey)
                      .where("itemAvailabilityPerOrder", isGreaterThan: 0)
                      .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  return ListView.builder(
                      itemCount: snapshot.data!.docs.length,
                      itemBuilder: (context, index) {
                        FoodMenu foodMenu = FoodMenu.fromDocumentSnapshot(
                            snapshot.data!.docs[index]);
                        return Visibility(
                          visible: foodMenu.itemType == _menu[_selectedIndex],
                          child: InkWell(
                            onLongPress: () {},
                            onTap: () => Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    ViewItemScreen(
                                        productName: foodMenu.itemName),
                              ),
                            ),
                            child: _itemCard(foodMenu),
                          ),
                        );
                      });
                } else {
                  return const SizedBox();
                }
              },
            ),
          ),
        ),
      ],
    );
  }

  _getCountWish() async {
    List<String> itemName = [];

    await FirebaseFirestore.instance
        .collection('seller')
        .get()
        .then((value) async {
      for (var items in value.docs) {
        itemName.add(items.id);
      }

      for (String collectedItems in itemName) {
        await FirebaseFirestore.instance
            .collection('seller/$collectedItems/wishlist')
            .where("email", isEqualTo: AuthController.getUserEmail())
            .get()
            .then(
              (value) => setState(() {
                value.size > 0 ? wishCount++ : wishCount = wishCount;
              }),
            );
      }
    });
  }

  _getCountCartUser() async {
    await FirebaseFirestore.instance
        .collection('cart')
        .where("email", isEqualTo: AuthController.getUserEmail())
        .get()
        .then(
          (value) => setState(() {
            cartCount = value.size;
          }),
        );
  }
}
