// ignore_for_file: no_leading_underscores_for_local_identifiers, avoid_function_literals_in_foreach_calls, avoid_print, prefer_final_fields

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/model/food_menu.dart';
import 'package:uthmfoodie/screens/user_page_screen.dart';
import 'package:uthmfoodie/screens/view_item_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';

class WishItemScreen extends StatefulWidget {
  const WishItemScreen({super.key});

  @override
  State<WishItemScreen> createState() => _WishItemScreenState();
}

class _WishItemScreenState extends State<WishItemScreen> {
  List<String> _selectedItem = [];
  List<FoodMenu> _wishListMenu = [];

  @override
  void initState() {
    _loadWishListItem();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) {
        if (didPop) {
          return;
        }
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) => const UserPageScreen(),
          ),
        );
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (BuildContext ctx) => const UserPageScreen(),
              ),
            ),
            icon: const Icon(Icons.arrow_back_outlined),
          ),
          title: Text(Strings.WishItemScreen),
        ),
        body: Container(
          padding: const EdgeInsets.all(10.0),
          child: StreamBuilder(
            stream: FirebaseFirestore.instance.collection('seller').snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListView.builder(
                    itemCount: snapshot.data!.docs.length,
                    itemBuilder: (context, index) {
                      FoodMenu foodMenu = FoodMenu.fromDocumentSnapshot(
                          snapshot.data!.docs[index]);
                      return InkWell(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (BuildContext context) =>
                                ViewItemScreen(productName: foodMenu.itemName),
                          ),
                        ),
                        child: Visibility(
                          visible: _selectedItem.contains(foodMenu.itemName),
                          child: Card(
                            elevation: 5,
                            child: Container(
                              padding: const EdgeInsets.all(10.0),
                              height: 100.0,
                              child: Row(
                                children: [
                                  Container(
                                    width: 80.0,
                                    decoration: BoxDecoration(
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                      image: DecorationImage(
                                        image: NetworkImage(foodMenu.itemImage),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10.0),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(height: 10.0),
                                        Text(
                                          foodMenu.itemName,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 8.0),
                                          child: Text(
                                            foodMenu.itemDescription,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Text(
                                          "Nutrition: ${foodMenu.itemNutrition}",
                                          overflow: TextOverflow.ellipsis,
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    });
              } else {
                return const SizedBox();
              }
            },
          ),
        ),
      ),
    );
  }

  _loadWishListItem() async {
    List<String> _itemName = [];
    try {
      await FirebaseFirestore.instance
          .collection('seller')
          .get()
          .then((value) async {
        for (var items in value.docs) {
          _itemName.add(items.id);
        }

        for (String collectedItems in _itemName) {
          try {
            await FirebaseFirestore.instance
                .collection('seller/$collectedItems/wishlist')
                .get()
                .then(
                  (value) => value.docs.forEach((wishElement) {
                    if (AuthController.getUserEmail() == wishElement["email"]) {
                      _selectedItem.add(collectedItems);
                    }
                  }),
                );
          } on FirebaseException catch (e) {
            print(e.message);
          } on Exception catch (e) {
            print(e);
          }
        }
      }).then((value) => _setFoodMenuItems());
    } on FirebaseException catch (e) {
      print(e.message);
    } on Exception catch (e) {
      print(e);
    }
  }

  _setFoodMenuItems() async {
    await FirebaseFirestore.instance.collection('seller').get().then((value) {
      value.docs.forEach((element) {
        setState(() {
          if (_selectedItem.contains(element.id)) {
            _wishListMenu.add(FoodMenu.fromMap(element.data()));
          }
        });
      });
    });
  }
}
