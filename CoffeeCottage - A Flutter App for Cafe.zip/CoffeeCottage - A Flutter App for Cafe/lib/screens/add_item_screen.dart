// ignore_for_file: empty_catches, unused_catch_clause, prefer_typing_uninitialized_variables, use_build_context_synchronously

import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_luban/flutter_luban.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/model/food_menu.dart';
import 'package:uthmfoodie/strings/strings.dart';
import 'package:uthmfoodie/util/system_defaults.dart';

class AddItemScreen extends StatefulWidget {
  final String productName;
  const AddItemScreen({super.key, required this.productName});

  @override
  State<AddItemScreen> createState() => _AddItemScreenState();
}

class _AddItemScreenState extends State<AddItemScreen> {
  var sellerCollection = FirebaseFirestore.instance.collection("seller");
  String _imageUrl = "";
  final picker = ImagePicker();
  var _finalImagePath;
  bool _isComplete = false;

  final TextEditingController _itemName = TextEditingController();
  final TextEditingController _itemDescription = TextEditingController();
  final TextEditingController _itemNutrition = TextEditingController();
  final TextEditingController _itemPrice = TextEditingController();
  final TextEditingController _itemDiscount = TextEditingController();
  final TextEditingController _itemAvailability = TextEditingController();
  final TextEditingController _itemType = TextEditingController();

  @override
  void dispose() {
    _itemName.dispose();
    _itemDescription.dispose();
    _itemNutrition.dispose();
    _itemPrice.dispose();
    _itemDiscount.dispose();
    _itemAvailability.dispose();
    _itemType.dispose();
    super.dispose();
  }

  @override
  void initState() {
    if (widget.productName.isNotEmpty) {
      _fetchProductData();
      _isComplete = true;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.productName.isEmpty
            ? Strings.AddItemScreen
            : Strings.AlterItemScreen),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.width,
              child: Scaffold(
                resizeToAvoidBottomInset: false,
                body: _imageUrl.isEmpty
                    ? _finalImagePath == null
                        ? Image.asset(
                            "images/placeholder.png",
                            fit: BoxFit.cover,
                            height: MediaQuery.of(context).size.width,
                          )
                        : Image.file(
                            _finalImagePath,
                            fit: BoxFit.cover,
                            height: MediaQuery.of(context).size.width,
                          )
                    : _imageUrl.isNotEmpty
                        ? Image.network(
                            _imageUrl,
                            fit: BoxFit.cover,
                            height: MediaQuery.of(context).size.width,
                          )
                        : Image.asset(
                            "images/placeholder.png",
                            fit: BoxFit.cover,
                            height: MediaQuery.of(context).size.width,
                          ),
                floatingActionButton: FloatingActionButton(
                  backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                  child: const Icon(
                    Icons.add_a_photo,
                    color: Color(0xff533c1c),
                  ),
                  onPressed: () => _showPicker(context: context),
                ),
              ),
            ),
            const SizedBox(height: 20.0),
            Container(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  TextFormField(
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: Strings.lblItemName,
                      labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                      floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                        (Set<MaterialState> states) {
                          final Color color =
                              states.contains(MaterialState.error)
                                  ? Theme.of(context).colorScheme.error
                                  : const Color.fromRGBO(255, 253, 235, 1.0);
                          return TextStyle(color: color, letterSpacing: 1.3);
                        },
                      ),
                    ),
                    validator: (String? value) {
                      if (value == null || value == '') {
                        _isComplete = false;
                        return '${Strings.manipulatorKeyInput} ${Strings.lblItemName}';
                      }
                      _isComplete = true;
                      return null;
                    },
                    enabled: widget.productName.isEmpty,
                    autovalidateMode: AutovalidateMode.always,
                    keyboardType: TextInputType.name,
                    controller: _itemName,
                  ),
                  const SizedBox(height: 20.0),
                  TextFormField(
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: Strings.lblItemDesc,
                      labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                      floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                        (Set<MaterialState> states) {
                          final Color color =
                              states.contains(MaterialState.error)
                                  ? Theme.of(context).colorScheme.error
                                  : const Color.fromRGBO(255, 253, 235, 1.0);
                          return TextStyle(color: color, letterSpacing: 1.3);
                        },
                      ),
                    ),
                    validator: (String? value) {
                      if (value == null || value == '') {
                        _isComplete = false;
                        return '${Strings.manipulatorKeyInput} ${Strings.lblItemDesc}';
                      }
                      _isComplete = true;
                      return null;
                    },
                    autovalidateMode: AutovalidateMode.always,
                    maxLines: 5,
                    keyboardType: TextInputType.name,
                    controller: _itemDescription,
                  ),
                  const SizedBox(height: 20.0),
                  TextFormField(
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: Strings.lblItemNutrition,
                      labelStyle: const TextStyle(color:  Color.fromRGBO(255, 253, 235, 1.0)),
                      floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                        (Set<MaterialState> states) {
                          final Color color =
                              states.contains(MaterialState.error)
                                  ? Theme.of(context).colorScheme.error
                                  : const Color.fromRGBO(255, 253, 235, 1.0);
                          return TextStyle(color: color, letterSpacing: 1.3);
                        },
                      ),
                    ),
                    validator: (String? value) {
                      if (value == null || value == '') {
                        _isComplete = false;
                        return '${Strings.manipulatorKeyInput} ${Strings.lblItemNutrition}';
                      }
                      _isComplete = true;
                      return null;
                    },
                    autovalidateMode: AutovalidateMode.always,
                    maxLines: 5,
                    keyboardType: TextInputType.text,
                    controller: _itemNutrition,
                  ),
                  const SizedBox(height: 20.0),
                  TextFormField(
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: Strings.lblPrice,
                      labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                      floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                        (Set<MaterialState> states) {
                          final Color color =
                              states.contains(MaterialState.error)
                                  ? Theme.of(context).colorScheme.error
                                  : const Color.fromRGBO(255, 253, 235, 1.0);
                          return TextStyle(color: color, letterSpacing: 1.3);
                        },
                      ),
                    ),
                    validator: (String? value) {
                      if (value == null || value == '') {
                        _isComplete = false;
                        return '${Strings.manipulatorKeyInput} ${Strings.lblPrice}';
                      }
                      _isComplete = true;
                      return null;
                    },
                    autovalidateMode: AutovalidateMode.always,
                    keyboardType: TextInputType.number,
                    controller: _itemPrice,
                  ),
                  const SizedBox(height: 20.0),
                  TextFormField(
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: Strings.lblDiscount,
                      labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                      floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                        (Set<MaterialState> states) {
                          final Color color =
                              states.contains(MaterialState.error)
                                  ? Theme.of(context).colorScheme.error
                                  : const Color.fromRGBO(255, 253, 235, 1.0);
                          return TextStyle(color: color, letterSpacing: 1.3);
                        },
                      ),
                    ),
                    validator: (String? value) {
                      if (value == null || value == '') {
                        _isComplete = false;
                        return '${Strings.manipulatorKeyInput} ${Strings.lblDiscount}';
                      }
                      _isComplete = true;
                      return null;
                    },
                    autovalidateMode: AutovalidateMode.always,
                    keyboardType: TextInputType.number,
                    controller: _itemDiscount,
                  ),
                  const SizedBox(height: 20.0),
                  TextFormField(
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: Strings.lblAvailability,
                      labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                      floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                        (Set<MaterialState> states) {
                          final Color color =
                              states.contains(MaterialState.error)
                                  ? Theme.of(context).colorScheme.error
                                  : const Color.fromRGBO(255, 253, 235, 1.0);
                          return TextStyle(color: color, letterSpacing: 1.3);
                        },
                      ),
                    ),
                    validator: (String? value) {
                      if (value == null || value == '') {
                        _isComplete = false;
                        return '${Strings.manipulatorKeyInput} ${Strings.lblAvailability}';
                      }
                      _isComplete = true;
                      return null;
                    },
                    autovalidateMode: AutovalidateMode.always,
                    keyboardType: TextInputType.number,
                    controller: _itemAvailability,
                  ),
                  const SizedBox(height: 20.0),
                  TextFormField(
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: Strings.lblItemType,
                      labelStyle: const TextStyle(color: Color.fromRGBO(255, 253, 235, 1.0)),
                      floatingLabelStyle: MaterialStateTextStyle.resolveWith(
                        (Set<MaterialState> states) {
                          final Color color =
                              states.contains(MaterialState.error)
                                  ? Theme.of(context).colorScheme.error
                                  : const Color.fromRGBO(255, 253, 235, 1.0);
                          return TextStyle(color: color, letterSpacing: 1.3);
                        },
                      ),
                    ),
                    validator: (String? value) {
                      if (value == null || value == '') {
                        var tempVal = Strings.lblItemType.split(" ");
                        _isComplete = false;
                        return '${Strings.manipulatorKeyInput} ${tempVal[0]} ${tempVal[1].toLowerCase()}';
                      }
                      _isComplete = true;
                      return null;
                    },
                    autovalidateMode: AutovalidateMode.always,
                    keyboardType: TextInputType.name,
                    controller: _itemType,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 100.0),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
        onPressed: () => _commit(),
        label: Text(
          Strings.btnPost,
          style: TextStyle(color: CustomAppColor.secondary),
        ),
        icon: Icon(
          Icons.send_rounded,
          color: CustomAppColor.secondary,
        ),
      ),
    );
  }

  _showPicker({required BuildContext context}) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: Text(Strings.lblPhotoLibrary),
                onTap: () {
                  _getImage(ImageSource.gallery);
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: Text(Strings.lblPhotoCamera),
                onTap: () {
                  _getImage(ImageSource.camera);
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  _fetchProductData() {
    sellerCollection.doc(widget.productName).get().then(
          (value) => setState(() {
            _itemName.text = value["itemName"];
            _itemDescription.text = value["itemDescription"];
            _itemNutrition.text = value["itemNutrition"];
            _imageUrl = value["itemImage"];
            _itemPrice.text = value["itemPrice"].toString();
            _itemDiscount.text = value["itemDiscount"].toString();
            _itemAvailability.text =
                value["itemAvailabilityPerOrder"].toString();
            _itemType.text = value["itemType"];
          }),
        );
  }

  _getImage(ImageSource source) async {
    var pickedFile = await picker.pickImage(source: source);
    var file = File(pickedFile!.path);
    Directory tempDir = await getTemporaryDirectory();
    CompressObject compressObject = CompressObject(
      imageFile: file, //image
      path: tempDir.path, //compress to path
      quality: 85, //first compress quality, default 80
      step:
          9, //compress quality step, The bigger the fast, Smaller is more accurate, default 6
      mode: CompressMode.LARGE2SMALL, //default AUTO
    );
    _imageUrl = "";
    Luban.compressImage(compressObject).then((path) {
      setState(() {
        _finalImagePath = File(path.toString());
      });
    });
  }

  _pushImageToCloud() async {
    //Upload to Firebase
    TaskSnapshot snapshot;
    try {
      snapshot = await FirebaseStorage.instance
          .ref()
          .child("${_itemName.text}.jpg")
          .putFile(_finalImagePath);
      return await snapshot.ref.getDownloadURL();
    } on FirebaseException catch (e) {}

    return;
  }

  _commit() async {
    if (widget.productName.isEmpty) {
      _imageUrl = await _pushImageToCloud();
    }
    if (_isComplete && _imageUrl.isNotEmpty) {
      FoodMenu menuItem = FoodMenu(
          itemName: _itemName.text,
          itemDescription: _itemDescription.text,
          itemNutrition: _itemNutrition.text,
          itemImage: _imageUrl,
          itemPrice: double.parse(_itemPrice.text),
          itemDiscount: double.parse(_itemDiscount.text),
          itemAvailabilityPerOrder: int.parse(_itemAvailability.text),
          itemType: _itemType.text);

      try {
        sellerCollection
            .doc(menuItem.itemName)
            .set(menuItem.toMap())
            .then((value) => Navigator.pop(context));
      } on FirebaseException catch (e) {
        SystemDefaults.showSnackBar(
            context: context, msg: e.message.toString(), duration: 5);
      }
    }
  }
}
