// ignore_for_file: empty_catches, unused_catch_clause, avoid_function_literals_in_foreach_calls

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/model/cart_model.dart';
import 'package:uthmfoodie/model/user_order_model.dart';
import 'package:uthmfoodie/strings/strings.dart';

class CurrentOrderStatus extends StatefulWidget {
  const CurrentOrderStatus({super.key});

  @override
  State<CurrentOrderStatus> createState() => _CurrentOrderStatusState();
}

class _CurrentOrderStatusState extends State<CurrentOrderStatus> {
  UserOrderData orderData = UserOrderData(
      orderId: "",
      email: "",
      promoCode: "",
      promoDiscountPrice: 0,
      totalPrice: 0,
      priceAfterDiscount: 0,
      orderDate: DateTime.now(),
      isServed: true,
      isPaid: false,
      isPrep: false,
      isInKitchen: false,
      isComplete: false,
      servedTime: DateTime.now(),
      statusLevel: 0,
      orderTime: '');
  List<CartData> _listOfCart = [];
  @override
  void initState() {
    _fetchOrderDetails();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(Strings.lblCurrentOrderStatus),
        actions: [
          IconButton(
              onPressed: () => _fetchOrderDetails(),
              icon: const Icon(Icons.refresh))
        ],
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        padding: const EdgeInsets.all(10.0),
        decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage("images/splash_bg.png"),
              fit: BoxFit.cover,
              opacity: .1),
        ),
        child: orderData.orderId.isEmpty
            ? Center(child: Text(Strings.lblNoActiveOrders))
            : Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Order Id : ${orderData.orderId}"),
                          Text(
                              "Date: ${DateFormat("dd/MM/yyyy hh:mm:ss aa").format(orderData.orderDate)}"),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 20.0),
                            child: Center(
                              child: CircleAvatar(
                                radius: 80.0,
                                backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                                child: orderData.isServed
                                    ? const Icon(
                                        Icons.check,
                                        color: Color(0xff533c1c),
                                        size: 140.0,
                                      )
                                    : Image.asset(
                                        _getImage().isEmpty
                                            ? "images/dish_pending.png"
                                            : _getImage(),
                                        width: 120.0,
                                      ),
                              ),
                            ),
                          ),
                          Center(
                            child: Text(
                              _getStatusText(),
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          const SizedBox(height: 40.0),
                          Column(
                            children: [
                              for (int i = 0; i < _listOfCart.length; i++)
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10.0, vertical: 10.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              _listOfCart[i].itemName,
                                              style: const TextStyle(
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                          Text("x ${_listOfCart[i].itemQty}")
                                        ],
                                      ),
                                      Text(
                                          "RM ${_listOfCart[i].totalItemPrice.toStringAsFixed(2)}")
                                    ],
                                  ),
                                ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  Visibility(
                    visible: orderData.isComplete,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10.0),
                      child: SizedBox(
                        height: 60.0,
                        width: MediaQuery.of(context).size.width,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(10.0),
                              ),
                            ),
                          ),
                          onPressed: () => _updateOrderToServe(),
                          child: Text(
                            Strings.btnServed,
                            style: TextStyle(
                                color: CustomAppColor.secondary,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  _fetchOrderDetails() async {
    await FirebaseFirestore.instance
        .collection("orders")
        .where("email", isEqualTo: AuthController.getUserEmail())
        .get()
        .then(
          (value) => value.docs.forEach(
            (element) {
              DateFormat dateFormat = DateFormat("dd/MM/yyyy");
              if (dateFormat.format(element["orderDate"].toDate()) ==
                  dateFormat.format(DateTime.now())) {
                if (!element["isServed"]) {
                  setState(() {
                    orderData = UserOrderData.fromMap(element.data());
                  });
                }
              }
            },
          ),
        )
        .then((value) async => await _fetchFoodMenuDetails());
  }

  String _getImage() {
    String image = "";

    if (orderData.isPrep) {
      setState(() {
        image = "images/dish_prep.png";
      });
    }
    if (orderData.isInKitchen) {
      setState(() {
        image = "images/dish_kitchen.png";
      });
    }
    if (orderData.isComplete) {
      setState(() {
        image = "images/dish_completed.png";
      });
    }

    return image;
  }

  String _getStatusText() {
    String status = "";

    if (!orderData.isServed) {
      if (_isNotChecked()) {
        setState(() {
          status = "In Waiting List";
        });
      } else {
        if (orderData.isPrep) {
          setState(() {
            status = "Preparing dish";
          });
        }
        if (orderData.isInKitchen) {
          setState(() {
            status = "In Kitchen";
          });
        }
        if (orderData.isComplete) {
          setState(() {
            status = "Ready to Serve";
          });
        }
      }
    } else {
      setState(() {
        status = "Already Served";
      });
    }

    return status;
  }

  bool _isNotChecked() =>
      !orderData.isPrep && !orderData.isInKitchen && !orderData.isComplete;

  _fetchFoodMenuDetails() async {
    await FirebaseFirestore.instance
        .collection("orders/${orderData.orderId}/listOfCart")
        .get()
        .then(
          (value) => _loadCartItemsIntoList(value),
        );
  }

  _loadCartItemsIntoList(QuerySnapshot<Map<String, dynamic>> value) {
    List<CartData> tempList = [];
    value.docs.forEach((element) {
      CartData cart = CartData.fromMap(element.data());
      tempList.add(cart);
    });

    setState(() {
      _listOfCart = tempList;
    });
  }

  _updateOrderToServe() async {
    try {
      await FirebaseFirestore.instance
          .collection("orders")
          .doc(orderData.orderId)
          .update({"isServed": true, "servedTime": DateTime.now()}).then(
              (value) => Navigator.of(context).pop());
    } on FirebaseException catch (e) {}
  }
}
