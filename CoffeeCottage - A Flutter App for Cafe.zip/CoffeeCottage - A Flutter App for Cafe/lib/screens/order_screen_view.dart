// ignore_for_file: await_only_futures, avoid_function_literals_in_foreach_calls

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/model/cart_model.dart';
import 'package:uthmfoodie/model/user_order_model.dart';
import 'package:uthmfoodie/strings/strings.dart';

class OrderScreenView extends StatefulWidget {
  final UserOrderData orders;
  const OrderScreenView({super.key, required this.orders});

  @override
  State<OrderScreenView> createState() => _OrderScreenViewState();
}

class _OrderScreenViewState extends State<OrderScreenView> {
  UserOrderData orders = UserOrderData(
      orderId: "",
      email: "",
      promoCode: "",
      promoDiscountPrice: 0,
      totalPrice: 0,
      priceAfterDiscount: 0,
      orderDate: DateTime.now(),
      isServed: true,
      isPaid: true,
      isPrep: true,
      isInKitchen: true,
      isComplete: true,
      servedTime: DateTime.now(),
      statusLevel: 0,
      orderTime: '');
  List<CartData> _listOfCart = [];

  bool isPrep = false, isInKitchen = false, isComplete = false;

  @override
  void initState() {
    setState(() {
      orders = widget.orders;
      isPrep = widget.orders.isPrep;
      isInKitchen = widget.orders.isInKitchen;
      isComplete = widget.orders.isComplete;
    });
    _fetchFoodMenuDetails();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.orders.orderId,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: Container(
        padding: const EdgeInsets.all(10.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Center(
                child: CircleAvatar(
                  radius: 80.0,
                  backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                  child: orders.isServed
                      ? const Icon(
                          Icons.check,
                          color:  Color(0xff533c1c),
                          size: 140.0,
                        )
                      : Image.asset(
                          _getImage().isEmpty
                              ? "images/dish_pending.png"
                              : _getImage(),
                          width: 120.0,
                        ),
                ),
              ),
              const SizedBox(height: 20.0),
              Text(
                orders.statusLevel == 0
                    ? Strings.lblDineIn
                    : Strings.lblTakeAway,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 30.0),
              ),
              Text(
                orders.orderTime.isEmpty ? "(Now)" : "(${orders.orderTime})",
                style: const TextStyle(fontSize: 20.0),
              ),
              const SizedBox(height: 40.0),
              Column(
                children: [
                  for (int i = 0; i < _listOfCart.length; i++)
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10.0, vertical: 10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  _listOfCart[i].itemName,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Text("x ${_listOfCart[i].itemQty}")
                            ],
                          ),
                          Text(
                              "RM ${_listOfCart[i].totalItemPrice.toStringAsFixed(2)}")
                        ],
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 40.0),
              Card(
                elevation: 5.0,
                child: Container(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(Strings.lblPrepDish),
                      ),
                      Visibility(
                        visible: !isPrep,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0)),
                          onPressed: () => _updateOrderDetails("isPrep"),
                          child: Text(
                            Strings.btnSet,
                            style: TextStyle(color: CustomAppColor.secondary),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: isPrep,
                        child: Column(
                          children: [
                            const Icon(
                              Icons.check,
                              color: Colors.green,
                            ),
                            Text(Strings.lblChecked)
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 5.0),
              Card(
                elevation: 5.0,
                child: Container(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(Strings.lblInKitchen),
                      ),
                      Visibility(
                        visible: !isInKitchen,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0)),
                          onPressed: () => _updateOrderDetails("isInKitchen"),
                          child: Text(
                            Strings.btnSet,
                            style: TextStyle(color: CustomAppColor.secondary),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: isInKitchen,
                        child: Column(
                          children: [
                            const Icon(
                              Icons.check,
                              color: Colors.green,
                            ),
                            Text(Strings.lblChecked)
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 5.0),
              Card(
                elevation: 5.0,
                child: Container(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(Strings.lblComplete),
                      ),
                      Visibility(
                        visible: !isComplete,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0)),
                          onPressed: () => _updateOrderDetails("isComplete"),
                          child: Text(
                            Strings.btnSet,
                            style: TextStyle(color: CustomAppColor.secondary),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: isComplete,
                        child: Column(
                          children: [
                            const Icon(
                              Icons.check,
                              color: Colors.green,
                            ),
                            Text(Strings.lblChecked)
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20.0),
            ],
          ),
        ),
      ),
    );
  }

  String _getImage() {
    String image = "";
    if (isPrep) {
      setState(() {
        image = "images/dish_prep.png";
      });
    }
    if (isInKitchen) {
      setState(() {
        image = "images/dish_kitchen.png";
      });
    }
    if (isComplete) {
      setState(() {
        image = "images/dish_completed.png";
      });
    }

    return image;
  }

  _updateOrderDetails(String orderProg) async {
    var ins = await FirebaseFirestore.instance
        .collection("orders")
        .doc(orders.orderId);
    setState(() {
      switch (orderProg) {
        case "isPrep":
          isPrep = true;
          ins.update({orderProg: true});
          break;
        case "isInKitchen":
          isInKitchen = true;
          ins.update({orderProg: true});
          break;
        case "isComplete":
          isComplete = true;
          ins.update({orderProg: true});
          break;
      }
    });
  }

  _fetchFoodMenuDetails() async {
    await FirebaseFirestore.instance
        .collection("orders/${orders.orderId}/listOfCart")
        .get()
        .then(
          (value) => _loadCartItemsIntoList(value),
        );
  }

  _loadCartItemsIntoList(QuerySnapshot<Map<String, dynamic>> value) {
    List<CartData> tempList = [];
    value.docs.forEach((element) {
      CartData cart = CartData.fromMap(element.data());
      tempList.add(cart);
    });

    setState(() {
      _listOfCart = tempList;
    });
  }
}
