import 'dart:async';

import 'package:flutter/material.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/screens/main_auth_launcher_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    if (AuthController.isActiveUser()) {
      AuthController.signOut();
    }
    _lauchMainPage();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/splash_bg.png"),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Color.fromRGBO(35, 29, 28, 0.08),
              BlendMode.dstATop,
            ),
          ),
        ),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Stack(
          children: [
            Image.asset(
              "images/header1.png",
              fit: BoxFit.fitWidth,
            ),
            Positioned(
              top: 50.0,
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
               
              ),
            ),
            Positioned(
              bottom: 0,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Image.asset(
                  "images/bottom_logo.png",
                  height: 400.0,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _lauchMainPage() {
    Timer(
      const Duration(seconds: 10),
      () => Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) => const MainAuthLauncherScreen()),
        (route) => false,
      ),
    );
  }
}
