// ignore_for_file: prefer_final_fields

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:uthmfoodie/controller/auth_controller.dart';
import 'package:uthmfoodie/global/colors.dart';
import 'package:uthmfoodie/model/cart_model.dart';
import 'package:uthmfoodie/screens/checkout_screen.dart';
import 'package:uthmfoodie/screens/user_page_screen.dart';
import 'package:uthmfoodie/strings/strings.dart';

class CartViewScreen extends StatefulWidget {
  const CartViewScreen({super.key});

  @override
  State<CartViewScreen> createState() => _CartViewScreenState();
}

class _CartViewScreenState extends State<CartViewScreen> {
  var cartCollection = FirebaseFirestore.instance.collection('cart');
  double _overallPrice = 0.0;
  List<int> _selectedIndex = [];
  List<CartData> _selectedItem = [];

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) {
        if (didPop) {
          return;
        }
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) => const UserPageScreen(),
          ),
        );
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
              onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (BuildContext ctx) => const UserPageScreen(),
                    ),
                  ),
              icon: const Icon(Icons.arrow_back)),
          title: Text(Strings.CartViewScreen),
        ),
        body: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: StreamBuilder(
                    stream: cartCollection
                        .where("email",
                            isEqualTo: AuthController.getUserEmail())
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return ListView.builder(
                            itemCount: snapshot.data!.docs.length,
                            itemBuilder: (context, index) {
                              CartData cart = CartData.fromDocumentSnapshot(
                                  snapshot.data!.docs[index]);
                              return InkWell(
                                  onTap: () => setState(() {
                                        if (_selectedIndex.contains(index)) {
                                          _selectedIndex.remove(index);
                                          _selectedItem.removeWhere((element) =>
                                              element.transId == cart.transId);
                                          double temp = _overallPrice -=
                                              cart.totalItemPrice;
                                          temp < 0
                                              ? _overallPrice = 0
                                              : _overallPrice = temp;
                                        } else {
                                          _selectedIndex.add(index);
                                          _selectedItem.add(cart);
                                          _overallPrice += cart.totalItemPrice;
                                        }
                                      }),
                                  child: _cardview(cart, index));
                            });
                      } else {
                        return const SizedBox();
                      }
                    },
                  ),
                ),
              ),
              Card(
                child: Container(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          "RM ${_overallPrice.toStringAsFixed(2)}",
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 20.0),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () => _checkOut(),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5.0)))),
                        child: Text(
                          Strings.btnCheckout,
                          style: TextStyle(color: CustomAppColor.secondary),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _cardview(CartData cart, int index) {
    return Card(
      child: Container(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          children: [
            Checkbox(
              value: _selectedIndex.contains(index) ? true : false,
              onChanged: (bool? value) {},
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    cart.itemName,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 20.0),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text("x${cart.itemQty}"),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text("RM ${cart.itemPrice.toStringAsFixed(2)}"),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text("Discount: ${cart.itemDiscount}%"),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Total Price: RM ${cart.totalItemPrice.toStringAsFixed(2)}",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color.fromRGBO(255, 253, 235, 1.0),
                        ),
                        onPressed: () => _removeItemFromCart(cart, index),
                        child: Text(
                          Strings.btnRemoveItem,
                          style: TextStyle(color: CustomAppColor.secondary),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  _removeItemFromCart(CartData cart, int index) async {
    setState(() {
      if (_selectedItem
          .where((element) => element.transId == cart.transId)
          .isNotEmpty) {
        double temp = _overallPrice -= cart.totalItemPrice;
        temp < 0 ? _overallPrice = 0 : _overallPrice = temp;
      }
    });
    await FirebaseFirestore.instance
        .collection("cart")
        .doc(cart.transId)
        .delete();
  }

  _checkOut() {
    if (_selectedItem.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext ctx) =>
              CheckOutScreen(cartItem: _selectedItem),
        ),
      );
    }
  }
}
