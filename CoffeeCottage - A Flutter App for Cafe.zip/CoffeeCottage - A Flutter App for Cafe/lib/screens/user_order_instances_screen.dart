// ignore_for_file: unused_import, non_constant_identifier_names, prefer_const_constructors, avoid_function_literals_in_foreach_calls

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uthmfoodie/model/cart_model.dart';
import 'package:uthmfoodie/model/user_order_model.dart';
import 'package:uthmfoodie/strings/strings.dart';

class UserOrderInstanceScreen extends StatefulWidget {
  final String OrderId;
  const UserOrderInstanceScreen({required this.OrderId, super.key});

  @override
  State<UserOrderInstanceScreen> createState() =>
      _UserOrderInstanceScreenState();
}

class _UserOrderInstanceScreenState extends State<UserOrderInstanceScreen> {
  late UserOrderData order;
  List<CartData> _listOfCart = [];
  @override
  void initState() {
    _fetchOrderDetails();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.OrderId),
      ),
      body: Container(
        padding: const EdgeInsets.all(10.0),
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage("images/splash_bg.png"),
              fit: BoxFit.cover,
              opacity: .1),
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: CircleAvatar(
                  radius: 60.0,
                  backgroundColor: const Color.fromRGBO(35, 29, 28, 1.0),
                  child: Image.asset("images/dish_completed.png"),
                ),
              ),
              const SizedBox(height: 50.0),
              Text("Order Id: ${widget.OrderId}"),
              Text(
                  "Order Date: ${DateFormat("dd/MM/yyyy hh:mm:ss aa").format(order.orderDate)}"),
              Text(
                  "Order Serving Time: ${DateFormat("dd/MM/yyyy hh:mm:ss aa").format(order.servedTime)}"),
              Text("Total Item Ordered: ${_listOfCart.length}"),
              const SizedBox(height: 10.0),
              Text(
                "Total Amount: RM${order.totalPrice.toStringAsFixed(2)}",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                "Price After Discount: RM${order.priceAfterDiscount.toStringAsFixed(2)}",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                "Promo Code: ${order.promoCode.isEmpty ? "N/A" : order.promoCode}",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 50.0),
              Text(Strings.lblItem),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 1.0,
                color: Colors.white,
              ),
              for (int i = 0; i < _listOfCart.length; i++)
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10.0, vertical: 10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              _listOfCart[i].itemName,
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Text("x ${_listOfCart[i].itemQty}")
                        ],
                      ),
                      Text(
                          "RM ${_listOfCart[i].totalItemPrice.toStringAsFixed(2)}"),
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: 1.0,
                        color: Colors.white,
                      ),
                    ],
                  ),
                ),

              // Text(data)
            ],
          ),
        ),
      ),
    );
  }

  _fetchOrderDetails() async {
    await FirebaseFirestore.instance
        .collection("orders")
        .doc(widget.OrderId)
        .get()
        .then(
          (value) => setState(() {
            order = UserOrderData.fromJson(value.data()!);
          }),
        )
        .then((value) => _fetchFoodMenuDetails());
  }

  _fetchFoodMenuDetails() async {
    await FirebaseFirestore.instance
        .collection("orders/${widget.OrderId}/listOfCart")
        .get()
        .then(
          (value) => _loadCartItemsIntoList(value),
        );
  }

  _loadCartItemsIntoList(QuerySnapshot<Map<String, dynamic>> value) {
    List<CartData> tempList = [];
    value.docs.forEach((element) {
      CartData cart = CartData.fromMap(element.data());
      tempList.add(cart);
    });

    setState(() {
      _listOfCart = tempList;
    });
  }
}
